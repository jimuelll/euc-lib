-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2026 at 07:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

--
-- Fresh-start reset
--
-- WARNING: this file is intentionally destructive. It removes only tables
-- owned by this application in the database currently selected by your SQL
-- client, then recreates the current baseline. This makes a retry after a
-- partial import safe; do not use it for an installation whose data you need
-- to retain.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS
  `account_challenges`, `email_address_claims`, `email_request_limits`, `email_deliveries`, `email_dispatch_state`, `email_quota_usage`,
  `restore_audit_events`,
  `system_maintenance_state`,
  `auth_restore_state`,
  `copy_holdings`,
  `book_copies`,
  `accession_claim_voids`,
  `accession_claim_corrections`,
  `accession_claims`,
  `catalog_settings`,
  `delivery_outbox`,
  `notification_reads`,
  `notifications`,
  `site_daily_visits`,
  `reservations`,
  `fine_ledger_entries`,
  `fine_accounts`,
  `clearance_transaction_items`,
  `clearance_transactions`,
  `attendance_logs`,
  `borrowings`,
  `recommendation_feedback`,
  `book_enrichment`,
  `book_embeddings`,
  `books`,
  `book_types`,
  `catalog_schema`,
  `auth_refresh_sessions`,
  `auth_audit_events`,
  `audit_events`,
  `bulletin_moderation_actions`,
  `bulletin_comment_reports`,
  `bulletin_moderation_cases`,
  `bulletin_reactions`,
  `bulletin_comment_helpful`,
  `bulletin_helpful`,
  `bulletin_saves`,
  `bulletin_event_interest`,
  `bulletin_comments`,
  `bulletin_likes`,
  `bulletin_posts`,
  `library_events`,
  `academic_subscriptions`,
  `library_holidays`,
  `library_circulation_settings`,
  `site_content_settings`,
  `about_settings`,
  `academic_terms`,
  `academic_programs`,
  `departments`,
  `backup_snapshots`,
  `backup_schedule`,
  `user_guide_modules`,
  `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------

CREATE TABLE `library_events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `library_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_library_events_starts_at` (`starts_at`),
  ADD KEY `fk_library_events_creator` (`created_by`);

ALTER TABLE `library_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `site_content_settings` (
  `id` tinyint NOT NULL,
  `hero_kicker` varchar(255) NOT NULL,
  `hero_title` varchar(255) NOT NULL,
  `hero_highlight` varchar(255) NOT NULL,
  `hero_description` text NOT NULL,
  `hero_image_url` varchar(2048) DEFAULT NULL,
  `hero_stats` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`hero_stats`)),
  `hours` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`hours`)),
  `address` varchar(500) NOT NULL,
  `contact_email` varchar(255) NOT NULL,
  `contact_phone` varchar(100) NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `about_settings`
--

CREATE TABLE `about_settings` (
  `id` int(11) NOT NULL,
  `library_name` varchar(255) NOT NULL DEFAULT 'Enverga-Candelaria Library',
  `established` year(4) DEFAULT NULL,
  `mission_title` varchar(255) DEFAULT NULL,
  `mission_text` text DEFAULT NULL,
  `history_title` varchar(255) DEFAULT NULL,
  `history_text` text DEFAULT NULL,
  `policies` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`policies`)),
  `facilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`facilities`)),
  `staff` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`staff`)),
  `spaces` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`spaces`)),
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `academic_subscriptions`
--

CREATE TABLE `academic_subscriptions` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(2048) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `image_url` varchar(2048) DEFAULT NULL,
  `image_public_id` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_logs`
--

CREATE TABLE `attendance_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `scanned_id` varchar(50) NOT NULL,
  `type` enum('check_in','check_out') NOT NULL,
  `purpose` enum('entry_exit','borrowing') NOT NULL DEFAULT 'entry_exit',
  `borrowing_id` int(11) DEFAULT NULL,
  `scanned_by` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_audit_events`
--

CREATE TABLE `auth_audit_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `event_type` enum('login','logout','password_changed') NOT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') NOT NULL DEFAULT 'unknown',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
--
-- Table structure for table `audit_events`
--

CREATE TABLE `audit_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `actor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `actor_name` varchar(255) DEFAULT NULL,
  `actor_role` varchar(64) DEFAULT NULL,
  `category` varchar(64) NOT NULL,
  `action` varchar(64) NOT NULL,
  `description` varchar(500) NOT NULL,
  `route` varchar(255) DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `event_key` varchar(64) DEFAULT NULL,
  `restore_status` enum('retained','reversed') NOT NULL DEFAULT 'retained',
  `reversed_at` datetime DEFAULT NULL,
  `reversed_by_restore_id` bigint(20) UNSIGNED DEFAULT NULL,
  `occurred_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_refresh_sessions`
--

CREATE TABLE `auth_refresh_sessions` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `jti` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `backup_snapshots`
--

CREATE TABLE `backup_snapshots` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cloudinary_public_id` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `size_bytes` bigint(20) UNSIGNED NOT NULL,
  `book_image_public_ids` json DEFAULT NULL,
  `kind` enum('manual','scheduled','pre_restore') NOT NULL DEFAULT 'manual',
  `label` varchar(120) DEFAULT NULL, `notes` varchar(500) DEFAULT NULL, `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL, `snapshot_version` int DEFAULT NULL,
  `verification_status` enum('unverified','verified','failed') NOT NULL DEFAULT 'unverified', `verified_at` datetime DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `material_type` enum('book','thesis') NOT NULL DEFAULT 'book',
  `metadata` json DEFAULT NULL,
  `image_url` varchar(2048) DEFAULT NULL,
  `image_public_id` varchar(255) DEFAULT NULL,
  `book_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `copies` int(11) DEFAULT 1,
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book_copies`
--

CREATE TABLE `book_copies` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `barcode` varchar(64) NOT NULL,
  `condition` enum('good','damaged','lost','weeded','discarded') NOT NULL DEFAULT 'good',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Per-copy acquisition and accession details used by circulation.
CREATE TABLE `copy_holdings` (
  `copy_id` int(11) NOT NULL,
  `accession_number` varchar(64) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `program_id` bigint(20) UNSIGNED DEFAULT NULL,
  `course_code` varchar(64) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `date_acquired` date DEFAULT NULL,
  `distributor` varchar(255) DEFAULT NULL,
  `invoice_reference` varchar(128) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permanent accession registry deliberately has no copy or user foreign key.
CREATE TABLE `accession_claims` (
  `accession_number` varchar(64) NOT NULL,
  `copy_barcode` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `copy_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `claimed_by` bigint(20) unsigned DEFAULT NULL,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`accession_number`),
  KEY `idx_accession_claims_barcode` (`copy_barcode`),
  KEY `idx_accession_claims_book_sequence` (`book_id`, `copy_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `accession_claim_voids` (
  `accession_number` varchar(64) NOT NULL,
  `copy_barcode` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `copy_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `voided_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`accession_number`),
  KEY `idx_accession_claim_voids_barcode` (`copy_barcode`),
  KEY `idx_accession_claim_voids_book` (`book_id`, `copy_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `accession_claim_corrections` (
  `correction_id` char(36) NOT NULL,
  `copy_barcode` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `copy_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `old_accession_number` varchar(64) NOT NULL,
  `new_accession_number` varchar(64) NOT NULL,
  `reason` varchar(500) NOT NULL,
  `corrected_by` bigint(20) unsigned DEFAULT NULL,
  `corrected_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`correction_id`),
  UNIQUE KEY `uq_accession_corrections_old` (`old_accession_number`),
  UNIQUE KEY `uq_accession_corrections_new` (`new_accession_number`),
  KEY `idx_accession_corrections_barcode` (`copy_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Recommendation vectors are operational data, intentionally separate from
-- flexible catalogue metadata so vectors are never exposed publicly.
CREATE TABLE `book_embeddings` (
  `book_id` int(11) NOT NULL,
  `model` varchar(128) NOT NULL,
  `content_hash` char(64) NOT NULL,
  `vector_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`vector_json`)),
  `dimensions` int(11) DEFAULT NULL,
  `status` enum('stale','ready','failed') NOT NULL DEFAULT 'stale',
  `embedded_at` datetime DEFAULT NULL,
  `last_error` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`book_id`),
  KEY `idx_book_embeddings_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `book_enrichment` (
  `book_id` int(11) NOT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'none',
  `enrichment_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`enrichment_json`)),
  `status` enum('stale','ready','failed') NOT NULL DEFAULT 'stale',
  `enriched_at` datetime DEFAULT NULL,
  `last_error` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`book_id`),
  KEY `idx_book_enrichment_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `recommendation_feedback` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) NOT NULL,
  `feedback` enum('dismissed') NOT NULL DEFAULT 'dismissed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_recommendation_feedback_user_book` (`user_id`, `book_id`),
  KEY `idx_recommendation_feedback_book` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book_types`
--

CREATE TABLE `book_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `default_borrow_days` int(11) DEFAULT NULL,
  `loan_duration_minutes` int(11) NOT NULL,
  `loan_duration_unit` enum('day','hour') NOT NULL DEFAULT 'day',
  `fine_per_hour` decimal(10,2) NOT NULL,
  `fine_interval` enum('hour','day') NOT NULL DEFAULT 'hour',
  `initial_fine` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrowings`
--

CREATE TABLE `borrowings` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) NOT NULL,
  `copy_id` int(11) DEFAULT NULL,
  `loan_policy_id_snapshot` bigint(20) UNSIGNED DEFAULT NULL,
  `loan_policy_name_snapshot` varchar(255) NOT NULL DEFAULT 'Unknown historical policy',
  `borrowed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `due_date` datetime NOT NULL,
  `loan_duration_minutes` int(11) DEFAULT NULL,
  `loan_duration_unit` enum('day','hour') DEFAULT NULL,
  `fine_per_hour` decimal(10,2) DEFAULT NULL,
  `fine_interval` enum('hour','day') DEFAULT NULL,
  `initial_fine` decimal(10,2) DEFAULT NULL,
  `returned_at` timestamp NULL DEFAULT NULL,
  `status` enum('borrowed','returned','overdue') NOT NULL DEFAULT 'borrowed',
  `notes` text DEFAULT NULL,
  `issued_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_overdue_notification_at` datetime DEFAULT NULL,
  `settled_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `settled_at` datetime DEFAULT NULL,
  `settled_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `active_copy_id` int(11) GENERATED ALWAYS AS (CASE WHEN `status` IN ('borrowed','overdue') AND `deleted_at` IS NULL THEN `copy_id` ELSE NULL END) STORED,
  `active_user_book_key` varchar(64) GENERATED ALWAYS AS (CASE WHEN `status` IN ('borrowed','overdue') AND `deleted_at` IS NULL THEN concat(`user_id`, ':', `book_id`) ELSE NULL END) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bulletin_comments`
--

CREATE TABLE `bulletin_comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bulletin_likes`
--

CREATE TABLE `bulletin_likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bulletin_posts`
--

CREATE TABLE `bulletin_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `excerpt` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(512) DEFAULT NULL,
  `image_public_id` varchar(512) DEFAULT NULL,
  `post_type` enum('announcement','event') NOT NULL DEFAULT 'announcement',
  `event_starts_at` datetime DEFAULT NULL,
  `event_ends_at` datetime DEFAULT NULL,
  `event_location` varchar(255) DEFAULT NULL,
  `event_registration_url` varchar(512) DEFAULT NULL,
  `author_id` bigint(20) UNSIGNED NOT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `catalog_schema`
--

CREATE TABLE `catalog_schema` (
  `id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `label` varchar(255) NOT NULL,
  `type` enum('text','textarea','number','date','select','repeatable') NOT NULL DEFAULT 'text',
  archived_options JSON NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL DEFAULT 0,
  `public` tinyint(1) NOT NULL DEFAULT 0,
  `archived` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 = field removed from active schema but data retained in books table'
  ,`scope` enum('shared','book','thesis') NOT NULL DEFAULT 'shared'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clearance_transactions`
--

CREATE TABLE `clearance_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `receipt_number` varchar(48) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `transaction_type` enum('payment','adjustment','reversal') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash') DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `reverses_transaction_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clearance_transaction_items`
--

CREATE TABLE `clearance_transaction_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `borrowing_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_circulation_settings`
--

CREATE TABLE `library_circulation_settings` (
  `id` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `overdue_fine_per_hour` decimal(10,2) NOT NULL DEFAULT 1.00,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `catalog_settings` (
  `id` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `show_unheld_in_opac` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_holidays`
--

CREATE TABLE `library_holidays` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `holiday_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `image_url` varchar(1024) DEFAULT NULL,
  `image_public_id` varchar(191) DEFAULT NULL,
  `image_alt` varchar(250) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'announcement',
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `href` varchar(255) DEFAULT NULL,
  `audience_type` enum('all','user','role','users') NOT NULL DEFAULT 'all',
  `audience_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `audience_role` enum('scanner','opac','employee','alumni','student','staff','admin','super_admin') DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `source_type` varchar(50) DEFAULT NULL,
  `source_id` bigint(20) DEFAULT NULL,
  `delivery_key` varchar(64) DEFAULT NULL,
  `email_requested` tinyint(1) NOT NULL DEFAULT 0,
  `email_batch_id` char(36) DEFAULT NULL,
  `email_expires_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_reads`
--

CREATE TABLE `notification_reads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `delivery_outbox` (
  `id` char(36) NOT NULL,
  `event_type` enum('notification','audit') NOT NULL,
  `payload` json NOT NULL,
  `status` enum('pending','delivered') NOT NULL DEFAULT 'pending',
  `attempts` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `available_at` datetime NOT NULL DEFAULT current_timestamp(),
  `locked_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `last_error` varchar(1000) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_delivery_outbox_pending` (`status`,`available_at`,`locked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) NOT NULL,
  `reserved_copy_id` int(11) DEFAULT NULL,
  `status` enum('pending','ready','cancelled','expired','fulfilled') NOT NULL DEFAULT 'pending',
  `reserved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `fulfilled_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `active_user_book_key` varchar(64) GENERATED ALWAYS AS (CASE WHEN `status` IN ('pending','ready') AND `deleted_at` IS NULL THEN concat(`user_id`, ':', `book_id`) ELSE NULL END) STORED,
  `ready_copy_id` int(11) GENERATED ALWAYS AS (CASE WHEN `status` = 'ready' AND `deleted_at` IS NULL THEN `reserved_copy_id` ELSE NULL END) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `site_daily_visits`
--

CREATE TABLE `site_daily_visits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_date` date NOT NULL,
  `visitor_id` varchar(64) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `first_path` varchar(255) DEFAULT NULL,
  `last_path` varchar(255) DEFAULT NULL,
  `first_visited_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_visited_at` datetime NOT NULL DEFAULT current_timestamp(),
  `hit_count` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_employee_id` varchar(50) NOT NULL,
  `library_card_number` varchar(64) DEFAULT NULL,
  `student_number` varchar(64) DEFAULT NULL,
  `employee_number` varchar(64) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `barcode` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('scanner','opac','employee','alumni','student','staff','admin','super_admin') NOT NULL DEFAULT 'student',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `address` varchar(100) NOT NULL DEFAULT '',
  `contact` varchar(11) NOT NULL DEFAULT '',
  `program_id` bigint(20) UNSIGNED DEFAULT NULL,
  `year_level` enum('1st Year','2nd Year','3rd Year','4th Year','Other') DEFAULT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `academic_term_id` bigint(20) UNSIGNED DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `_unique_sid` varchar(80) GENERATED ALWAYS AS (if(`deleted_at` is null,`student_employee_id`,concat('__deleted__',`student_employee_id`,'_',`deleted_at`))) STORED,
  `_unique_email` varchar(280) GENERATED ALWAYS AS (if(`deleted_at` is null,`email`,concat('__deleted__',`email`,'_',`deleted_at`))) STORED,
  `_unique_barcode` varchar(90) GENERATED ALWAYS AS (if(`deleted_at` is null,`barcode`,concat('__deleted__',`barcode`,'_',`deleted_at`))) STORED,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Table structure for table `user_guide_modules`
-- Draft content is kept separate from the published copy so editors can save
-- unfinished work without changing the live guide.
--

CREATE TABLE `user_guide_modules` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` varchar(120) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `draft_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`draft_content`)),
  `published_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`published_content` IS NULL OR json_valid(`published_content`)),
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `published_at` datetime DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_guide_slug` (`slug`),
  KEY `idx_user_guide_published_order` (`is_published`,`deleted_at`,`sort_order`),
  KEY `fk_user_guide_created_by` (`created_by`),
  KEY `fk_user_guide_updated_by` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Table structure for table `academic_programs`
--

CREATE TABLE `academic_programs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_departments_name` (`name`),
  KEY `fk_departments_created_by` (`created_by`),
  KEY `fk_departments_updated_by` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `academic_terms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `starts_on` date NOT NULL,
  `ends_on` date NOT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT 0,
  `current_term_key` tinyint(1) GENERATED ALWAYS AS (CASE WHEN `is_current` = 1 THEN 1 ELSE NULL END) STORED,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_settings`
--
ALTER TABLE `about_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_about_updated_by` (`updated_by`);

--
-- Indexes for table `academic_subscriptions`
--
ALTER TABLE `academic_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active_order` (`is_active`,`sort_order`),
  ADD KEY `fk_sub_created_by` (`created_by`),
  ADD KEY `fk_sub_updated_by` (`updated_by`);

--
-- Indexes for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_date` (`user_id`,`created_at`),
  ADD KEY `idx_purpose` (`purpose`),
  ADD KEY `fk_att_borrowing` (`borrowing_id`),
  ADD KEY `fk_att_scanned_by` (`scanned_by`),
  ADD KEY `idx_purpose_date` (`purpose`,`created_at`,`id`);

--
-- Indexes for table `auth_audit_events`
--
ALTER TABLE `auth_audit_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_auth_audit_user_time` (`user_id`,`created_at`);

--
-- Indexes for table `audit_events`
--
ALTER TABLE `audit_events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_audit_events_event_key` (`event_key`),
  ADD KEY `idx_audit_events_time` (`occurred_at`),
  ADD KEY `idx_audit_events_category_time` (`category`,`occurred_at`),
  ADD KEY `idx_audit_events_actor_time` (`actor_id`,`occurred_at`),
  ADD KEY `idx_audit_events_restore_status_time` (`restore_status`,`occurred_at`),
  ADD KEY `idx_audit_events_restore_id` (`reversed_by_restore_id`);

--
-- Indexes for table `auth_refresh_sessions`
--
ALTER TABLE `auth_refresh_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `jti` (`jti`),
  ADD KEY `idx_auth_refresh_sessions_user_id` (`user_id`),
  ADD KEY `idx_auth_refresh_sessions_expires_at` (`expires_at`),
  ADD KEY `idx_auth_refresh_sessions_revoked_at` (`revoked_at`);

--
-- Indexes for table `backup_snapshots`
--
ALTER TABLE `backup_snapshots`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_backup_snapshots_cloudinary_public_id` (`cloudinary_public_id`),
  ADD KEY `idx_backup_snapshots_created_at` (`created_at`),
  ADD KEY `idx_backup_snapshots_created_by` (`created_by`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_books_isbn` (`isbn`),
  ADD KEY `idx_books_deleted` (`deleted_at`),
  ADD KEY `idx_books_material_type` (`material_type`),
  ADD KEY `fk_books_book_type` (`book_type_id`);

--
-- Indexes for table `book_copies`
--
ALTER TABLE `book_copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_barcode` (`barcode`),
  ADD KEY `idx_book_id` (`book_id`),
  ADD KEY `idx_copies_deleted` (`deleted_at`);

--
-- Indexes for table `book_types`
--
ALTER TABLE `book_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_book_types_name` (`name`);

--
-- Indexes for table `borrowings`
--
ALTER TABLE `borrowings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_borrowings_user` (`user_id`),
  ADD KEY `fk_borrowings_book` (`book_id`),
  ADD KEY `fk_borrowings_issued_by` (`issued_by`),
  ADD KEY `idx_user_status` (`user_id`,`status`),
  ADD KEY `idx_book_id` (`book_id`),
  ADD KEY `fk_borrowings_copy` (`copy_id`),
  ADD KEY `idx_borrowings_deleted` (`deleted_at`),
  ADD UNIQUE KEY `uq_borrowings_active_copy` (`active_copy_id`),
  ADD UNIQUE KEY `uq_borrowings_active_user_book` (`active_user_book_key`);

--
-- Indexes for table `bulletin_comments`
--
ALTER TABLE `bulletin_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_post_id` (`post_id`),
  ADD KEY `fk_bc_user` (`user_id`),
  ADD KEY `idx_bulletin_comments_deleted` (`deleted_at`);

--
-- Indexes for table `bulletin_likes`
--
ALTER TABLE `bulletin_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_like` (`post_id`,`user_id`),
  ADD KEY `fk_bl_user` (`user_id`);

--
-- Indexes for table `bulletin_posts`
--
ALTER TABLE `bulletin_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `fk_bp_author` (`author_id`),
  ADD KEY `idx_bulletin_posts_deleted` (`deleted_at`),
  ADD KEY `idx_bulletin_events_upcoming` (`post_type`, `event_starts_at`);

--
-- Indexes for table `catalog_schema`
--
ALTER TABLE `catalog_schema`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_key` (`key`),
  ADD UNIQUE KEY `uq_catalog_schema_key` (`key`);

--
-- Indexes for table `clearance_transactions`
--
ALTER TABLE `clearance_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_clearance_receipt_number` (`receipt_number`),
  ADD KEY `idx_clearance_user_created` (`user_id`,`created_at`),
  ADD KEY `idx_clearance_reversal` (`reverses_transaction_id`),
  ADD KEY `fk_clearance_created_by` (`created_by`);

--
-- Indexes for table `clearance_transaction_items`
--
ALTER TABLE `clearance_transaction_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_clearance_item_borrowing` (`borrowing_id`),
  ADD KEY `idx_clearance_item_transaction` (`transaction_id`);

--
-- Indexes for table `catalog_settings`
--
ALTER TABLE `catalog_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_catalog_settings_updated_by` (`updated_by`);

--
-- Indexes for table `copy_holdings`
--
ALTER TABLE `copy_holdings`
  ADD PRIMARY KEY (`copy_id`),
  ADD UNIQUE KEY `uq_copy_holdings_accession_number` (`accession_number`),
  ADD KEY `idx_copy_holdings_program` (`program_id`),
  ADD KEY `fk_copy_holdings_created_by` (`created_by`),
  ADD KEY `fk_copy_holdings_updated_by` (`updated_by`);

-- Accessions remain claimed after an application restore.

--
-- Indexes for table `library_circulation_settings`
--
ALTER TABLE `library_circulation_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_library_circulation_settings_updated_by` (`updated_by`);

--
-- Indexes for table `library_holidays`
--
ALTER TABLE `library_holidays`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_library_holidays_date` (`holiday_date`),
  ADD KEY `idx_library_holidays_active_date` (`is_active`,`holiday_date`),
  ADD KEY `fk_library_holidays_created_by` (`created_by`),
  ADD KEY `fk_library_holidays_updated_by` (`updated_by`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_notifications_delivery_key` (`delivery_key`),
  ADD KEY `idx_notifications_active_created` (`is_active`,`created_at`),
  ADD KEY `idx_notifications_audience_user` (`audience_type`,`audience_user_id`),
  ADD KEY `idx_notifications_audience_role` (`audience_type`,`audience_role`),
  ADD KEY `fk_notifications_created_by` (`created_by`),
  ADD KEY `fk_notifications_audience_user` (`audience_user_id`);

--
-- Indexes for table `notification_reads`
--
ALTER TABLE `notification_reads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_notification_reads` (`notification_id`,`user_id`),
  ADD KEY `idx_notification_reads_user` (`user_id`,`read_at`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_status` (`user_id`,`status`),
  ADD KEY `idx_book_status` (`book_id`,`status`),
  ADD KEY `idx_reservations_deleted` (`deleted_at`),
  ADD KEY `fk_reservation_copy` (`reserved_copy_id`),
  ADD UNIQUE KEY `uq_reservations_active_user_book` (`active_user_book_key`),
  ADD UNIQUE KEY `uq_reservations_ready_copy` (`ready_copy_id`);

--
-- Indexes for table `site_daily_visits`
--
ALTER TABLE `site_daily_visits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_site_daily_visits_date_visitor` (`visit_date`,`visitor_id`),
  ADD KEY `idx_site_daily_visits_user_date` (`user_id`,`visit_date`),
  ADD KEY `idx_site_daily_visits_last_visited_at` (`last_visited_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `uq_active_sid` (`_unique_sid`),
  ADD UNIQUE KEY `uq_active_email` (`_unique_email`),
  ADD UNIQUE KEY `uq_active_barcode` (`_unique_barcode`),
  ADD KEY `idx_users_deleted` (`deleted_at`),
  ADD KEY `idx_users_program` (`program_id`),
  ADD KEY `idx_users_department` (`department_id`),
  ADD KEY `idx_users_academic_term` (`academic_term_id`);

ALTER TABLE `academic_programs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_academic_program_name` (`name`);

ALTER TABLE `academic_terms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_academic_terms_single_current` (`current_term_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_settings`
--
ALTER TABLE `about_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `academic_subscriptions`
--
ALTER TABLE `academic_subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_audit_events`
--
ALTER TABLE `auth_audit_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_events`
--
ALTER TABLE `audit_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_refresh_sessions`
--
ALTER TABLE `auth_refresh_sessions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backup_snapshots`
--
ALTER TABLE `backup_snapshots`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book_copies`
--
ALTER TABLE `book_copies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book_types`
--
ALTER TABLE `book_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `borrowings`
--
ALTER TABLE `borrowings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bulletin_comments`
--
ALTER TABLE `bulletin_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bulletin_likes`
--
ALTER TABLE `bulletin_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bulletin_posts`
--
ALTER TABLE `bulletin_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `catalog_schema`
--
ALTER TABLE `catalog_schema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clearance_transactions`
--
ALTER TABLE `clearance_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clearance_transaction_items`
--
ALTER TABLE `clearance_transaction_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `library_holidays`
--
ALTER TABLE `library_holidays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_reads`
--
ALTER TABLE `notification_reads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_daily_visits`
--
ALTER TABLE `site_daily_visits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `academic_programs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `academic_terms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

-- Add these constraints after AUTO_INCREMENT changes. MySQL 8 rejects
-- changing a referenced column while another table's foreign key exists.
ALTER TABLE `catalog_settings`
  ADD CONSTRAINT `fk_catalog_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `copy_holdings`
  ADD CONSTRAINT `fk_copy_holdings_copy` FOREIGN KEY (`copy_id`) REFERENCES `book_copies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_copy_holdings_program` FOREIGN KEY (`program_id`) REFERENCES `academic_programs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_copy_holdings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_copy_holdings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `about_settings`
--
ALTER TABLE `about_settings`
  ADD CONSTRAINT `fk_about_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `academic_subscriptions`
--
ALTER TABLE `academic_subscriptions`
  ADD CONSTRAINT `fk_sub_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sub_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `attendance_logs`
--
ALTER TABLE `attendance_logs`
  ADD CONSTRAINT `fk_att_borrowing` FOREIGN KEY (`borrowing_id`) REFERENCES `borrowings` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_att_scanned_by` FOREIGN KEY (`scanned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_att_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `auth_audit_events`
--
ALTER TABLE `auth_audit_events`
  ADD CONSTRAINT `fk_auth_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_program` FOREIGN KEY (`program_id`) REFERENCES `academic_programs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_academic_term` FOREIGN KEY (`academic_term_id`) REFERENCES `academic_terms` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `departments`
  ADD CONSTRAINT `fk_departments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_departments_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `user_guide_modules`
  ADD CONSTRAINT `fk_user_guide_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_guide_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `fk_books_book_type` FOREIGN KEY (`book_type_id`) REFERENCES `book_types` (`id`);

--
-- Constraints for table `book_copies`
--
ALTER TABLE `book_copies`
  ADD CONSTRAINT `fk_copy_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `borrowings`
--
ALTER TABLE `borrowings`
  ADD CONSTRAINT `fk_borrowings_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `fk_borrowings_copy` FOREIGN KEY (`copy_id`) REFERENCES `book_copies` (`id`),
  ADD CONSTRAINT `fk_borrowings_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_borrowings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `bulletin_comments`
--
ALTER TABLE `bulletin_comments`
  ADD CONSTRAINT `fk_bc_post` FOREIGN KEY (`post_id`) REFERENCES `bulletin_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_bc_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bulletin_likes`
--
ALTER TABLE `bulletin_likes`
  ADD CONSTRAINT `fk_bl_post` FOREIGN KEY (`post_id`) REFERENCES `bulletin_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_bl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bulletin_posts`
--
ALTER TABLE `bulletin_posts`
  ADD CONSTRAINT `fk_bp_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `clearance_transactions`
--
ALTER TABLE `clearance_transactions`
  ADD CONSTRAINT `fk_clearance_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_clearance_reverses` FOREIGN KEY (`reverses_transaction_id`) REFERENCES `clearance_transactions` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_clearance_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `clearance_transaction_items`
--
ALTER TABLE `clearance_transaction_items`
  ADD CONSTRAINT `fk_clearance_item_borrowing` FOREIGN KEY (`borrowing_id`) REFERENCES `borrowings` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_clearance_item_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `clearance_transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- Fine-ledger tables are created after their borrowing and transaction-item
-- parent keys exist, so a fresh import works on MySQL and MariaDB alike.
CREATE TABLE `fine_accounts` (
  `borrowing_id` int(11) NOT NULL PRIMARY KEY,
  `charged_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cycle_base_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `policy_due_date` datetime DEFAULT NULL,
  `policy_rate` decimal(12,2) DEFAULT NULL,
  `policy_interval` varchar(16) DEFAULT NULL,
  `policy_initial` decimal(12,2) DEFAULT NULL,
  `policy_baseline` decimal(12,2) DEFAULT NULL,
  `assessed_through_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT `fk_fine_account_borrowing` FOREIGN KEY (`borrowing_id`) REFERENCES `borrowings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `fine_ledger_entries` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `borrowing_id` int(11) NOT NULL,
  `kind` enum('charge','payment','adjustment','reversal','legacy_charge','legacy_credit') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `effective_at` datetime NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `transaction_item_id` bigint(20) UNSIGNED DEFAULT NULL,
  KEY `idx_fine_entry_borrowing` (`borrowing_id`,`id`),
  KEY `idx_fine_entry_effective` (`kind`,`effective_at`),
  UNIQUE KEY `uq_fine_entry_transaction_item` (`transaction_item_id`),
  CONSTRAINT `fk_fine_entry_account` FOREIGN KEY (`borrowing_id`) REFERENCES `fine_accounts` (`borrowing_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fine_entry_item` FOREIGN KEY (`transaction_item_id`) REFERENCES `clearance_transaction_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Constraints for table `library_circulation_settings`
--
ALTER TABLE `library_circulation_settings`
  ADD CONSTRAINT `fk_library_circulation_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `library_holidays`
--
ALTER TABLE `library_holidays`
  ADD CONSTRAINT `fk_library_holidays_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_library_holidays_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_audience_user` FOREIGN KEY (`audience_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notifications_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notification_reads`
--
ALTER TABLE `notification_reads`
  ADD CONSTRAINT `fk_notification_reads_notification` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notification_reads_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_res_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `fk_reservation_copy` FOREIGN KEY (`reserved_copy_id`) REFERENCES `book_copies` (`id`),
  ADD CONSTRAINT `fk_res_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

CREATE TABLE `auth_restore_state` (
  `id` tinyint NOT NULL,
  `invalid_before` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `system_maintenance_state` (
  `id` tinyint NOT NULL,
  `mode` enum('normal','restoring') NOT NULL DEFAULT 'normal',
  `started_at` datetime DEFAULT NULL,
  `started_by` bigint unsigned DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `restore_audit_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `snapshot_id` bigint unsigned DEFAULT NULL,
  `snapshot_kind` varchar(32) DEFAULT NULL,
  `restored_by` bigint unsigned DEFAULT NULL,
  `pre_restore_snapshot_id` bigint unsigned DEFAULT NULL,
  `restored_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_restore_audit_time` (`restored_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`student_employee_id`, `name`, `password_hash`, `role`, `is_active`, `must_change_password`, `address`, `contact`)
VALUES ('SA0001', 'Development Super Admin', '$2b$12$buA8cKPLUl3yVNMs01sibeSWY4/0AFzv/FNPNUa61RLI3CryzEHpG', 'super_admin', 1, 0, '', '');

INSERT INTO `about_settings` (`id`, `library_name`, `mission_title`, `mission_text`, `history_title`, `history_text`, `policies`, `facilities`, `staff`, `spaces`)
VALUES (1, 'Enverga-Candelaria Library', 'Empowering Academic Growth', '', '', '', '[]', '[]', '[]', '[]')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`);

INSERT INTO `book_types` (`name`, `default_borrow_days`, `loan_duration_minutes`, `loan_duration_unit`, `fine_per_hour`, `fine_interval`, `initial_fine`, `is_active`)
VALUES ('General collection', 7, 10080, 'day', 1.00, 'hour', 0.00, 1);

INSERT INTO `catalog_schema` (`key`, `label`, `type`, `options`, `required`, `locked`, `order`, `public`, `archived`, `scope`) VALUES
('title', 'Title', 'text', NULL, 1, 1, 0, 1, 0, 'shared'),
('author', 'Author', 'text', NULL, 1, 1, 1, 1, 0, 'shared'),
('isbn', 'ISBN', 'text', NULL, 0, 1, 2, 1, 0, 'book'),
('publisher', 'Publisher', 'text', NULL, 0, 0, 3, 1, 0, 'book'),
('publication_place', 'Publication Place', 'text', NULL, 0, 0, 4, 1, 0, 'book'),
('copyright_year', 'Copyright Year', 'number', NULL, 0, 0, 5, 1, 0, 'book'),
('edition', 'Edition', 'text', NULL, 0, 0, 6, 1, 0, 'book'),
('physical_description', 'Physical Description', 'textarea', NULL, 0, 0, 7, 1, 0, 'book'),
('category', 'Category', 'select', JSON_ARRAY('Circulation', 'Reserved', 'New Arrival', 'Filipiniana', 'General Reference', 'Special Collection', 'Cultural', 'Fiction'), 0, 0, 8, 1, 0, 'book'),
('call_number', 'Call Number', 'text', NULL, 0, 0, 9, 0, 0, 'book'),
('subjects', 'Subjects', 'repeatable', NULL, 0, 0, 10, 1, 0, 'book'),
('added_title', 'Added Title', 'text', NULL, 0, 0, 11, 1, 0, 'book'),
('series_title', 'Series Title', 'text', NULL, 0, 0, 12, 1, 0, 'book'),
('added_authors', 'Added Authors', 'repeatable', NULL, 0, 0, 13, 1, 0, 'book'),
('editors', 'Editors', 'repeatable', NULL, 0, 0, 14, 1, 0, 'book'),
('coordinators', 'Coordinators', 'repeatable', NULL, 0, 0, 15, 1, 0, 'book'),
('consultants', 'Consultants', 'repeatable', NULL, 0, 0, 16, 1, 0, 'book'),
('contributors', 'Contributors', 'repeatable', NULL, 0, 0, 17, 1, 0, 'book'),
('illustrators', 'Illustrators', 'repeatable', NULL, 0, 0, 18, 1, 0, 'book'),
('copies', 'Copies', 'number', NULL, 0, 1, 19, 1, 0, 'book'),
('thesis_program', 'Program', 'text', NULL, 1, 1, 20, 1, 0, 'thesis'),
('thesis_adviser', 'Adviser', 'text', NULL, 0, 1, 21, 1, 0, 'thesis'),
('academic_year', 'Academic Year', 'text', NULL, 1, 1, 22, 1, 0, 'thesis'),
('accession_number', 'Accession Number', 'text', NULL, 1, 1, 23, 1, 0, 'thesis'),
('thesis_keywords', 'Keywords', 'textarea', NULL, 0, 1, 24, 1, 0, 'thesis'),
('thesis_abstract', 'Abstract', 'textarea', NULL, 0, 1, 25, 0, 0, 'thesis');

INSERT INTO `library_circulation_settings` (`id`, `overdue_fine_per_hour`) VALUES (1, 1.00)
ON DUPLICATE KEY UPDATE `overdue_fine_per_hour` = VALUES(`overdue_fine_per_hour`);
INSERT INTO `catalog_settings` (`id`, `show_unheld_in_opac`) VALUES (1, 1)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`);
INSERT INTO `site_content_settings` (`id`, `hero_kicker`, `hero_title`, `hero_highlight`, `hero_description`, `hours`, `hero_stats`, `address`, `contact_email`, `contact_phone`) VALUES
(1, 'Manuel S. Enverga University Foundation — Candelaria Inc.', 'Enverga-Candelaria', 'Library', 'Digitalized inventory tracking, book reservations, and seamless access to library services — built for academic excellence.', '[{"day":"Monday – Friday","time":"7:00 AM – 9:00 PM","open":true},{"day":"Saturday","time":"8:00 AM – 5:00 PM","open":true},{"day":"Sunday","time":"Closed","open":false}]', '[{"value":"12,000+","label":"Volumes"},{"value":"400+","label":"Journals"},{"value":"24/7","label":"Digital Access"}]', '', '', '')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`);
INSERT INTO `auth_restore_state` (`id`) VALUES (1)
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`);
INSERT INTO `system_maintenance_state` (`id`, `mode`) VALUES (1, 'normal')
ON DUPLICATE KEY UPDATE `mode` = VALUES(`mode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

DELIMITER //
CREATE TRIGGER `trg_accession_claims_identity_insert` BEFORE INSERT ON `accession_claims` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 AND NOT EXISTS (SELECT 1 FROM book_copies bc WHERE bc.id = NEW.copy_id AND bc.barcode = NEW.copy_barcode AND bc.book_id = NEW.book_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession claim must identify an existing physical copy';
  END IF;
END//
CREATE TRIGGER `trg_accession_claims_no_update` BEFORE UPDATE ON `accession_claims` FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession claims are immutable'; END//
CREATE TRIGGER `trg_accession_claims_no_delete` BEFORE DELETE ON `accession_claims` FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession claims cannot be deleted'; END//
CREATE TRIGGER `trg_accession_corrections_no_update` BEFORE UPDATE ON `accession_claim_corrections` FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession correction history is immutable'; END//
CREATE TRIGGER `trg_accession_corrections_no_delete` BEFORE DELETE ON `accession_claim_corrections` FOR EACH ROW
BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession correction history cannot be deleted'; END//
CREATE TRIGGER `trg_accession_corrections_validate_insert` BEFORE INSERT ON `accession_claim_corrections` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession correction events are legacy history and cannot be created';
  END IF;
END//
CREATE TRIGGER `trg_accession_claim_voids_validate_insert` BEFORE INSERT ON `accession_claim_voids` FOR EACH ROW
BEGIN
  IF NOT EXISTS (SELECT 1 FROM accession_claims claim WHERE claim.accession_number = NEW.accession_number AND claim.copy_barcode = NEW.copy_barcode AND claim.book_id = NEW.book_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only the original physical copy may void its permanently claimed accession';
  END IF;
END//
CREATE TRIGGER `trg_accession_claim_voids_no_update` BEFORE UPDATE ON `accession_claim_voids` FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession void events are immutable';
END//
CREATE TRIGGER `trg_accession_claim_voids_no_delete` BEFORE DELETE ON `accession_claim_voids` FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Accession void events cannot be deleted';
END//
CREATE TRIGGER `trg_book_copies_claim_identity_insert` BEFORE INSERT ON `book_copies` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 AND EXISTS (SELECT 1 FROM accession_claims claim WHERE claim.copy_barcode = NEW.barcode) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A barcode reserved by permanent accession history cannot be reused';
  END IF;
END//
CREATE TRIGGER `trg_copy_holdings_claim_insert` BEFORE INSERT ON `copy_holdings` FOR EACH ROW
BEGIN
  IF NOT EXISTS (SELECT 1 FROM accession_claims ac JOIN book_copies bc ON bc.id = NEW.copy_id WHERE ac.accession_number = NEW.accession_number AND ac.copy_barcode = bc.barcode AND ac.book_id = bc.book_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Create the permanent accession claim before assigning the holding';
  END IF;
END//
CREATE TRIGGER `trg_copy_holdings_claim_update` BEFORE UPDATE ON `copy_holdings` FOR EACH ROW
BEGIN
  IF NEW.copy_id <> OLD.copy_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A holding cannot be transferred to another physical copy';
  END IF;
  IF BINARY NEW.accession_number <> BINARY OLD.accession_number THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An assigned accession number is permanent and cannot be changed';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM accession_claims ac JOIN book_copies bc ON bc.id = NEW.copy_id WHERE ac.accession_number = NEW.accession_number AND ac.copy_barcode = bc.barcode AND ac.book_id = bc.book_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Holding accession does not match its permanent claim';
  END IF;
END//
CREATE TRIGGER `trg_copy_holdings_claim_delete` BEFORE DELETE ON `copy_holdings` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 AND EXISTS (SELECT 1 FROM accession_claims ac WHERE ac.accession_number = OLD.accession_number) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A claimed accession cannot be removed from holdings';
  END IF;
END//
CREATE TRIGGER `trg_books_accession_claim_delete` BEFORE DELETE ON `books` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 AND EXISTS (
    SELECT 1 FROM book_copies bc JOIN accession_claims ac ON ac.copy_barcode = bc.barcode
     WHERE bc.book_id = OLD.id
  ) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A book with a claimed accession cannot be hard-deleted';
  END IF;
END//
CREATE TRIGGER `trg_books_accession_claim_identity` BEFORE UPDATE ON `books` FOR EACH ROW
BEGIN
  IF NEW.id <> OLD.id AND EXISTS (SELECT 1 FROM book_copies bc JOIN accession_claims ac ON ac.copy_barcode = bc.barcode WHERE bc.book_id = OLD.id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A book with a claimed accession cannot change identity';
  END IF;
END//
CREATE TRIGGER `trg_book_copies_claim_delete` BEFORE DELETE ON `book_copies` FOR EACH ROW
BEGIN
  IF COALESCE(@allow_accession_restore, 0) <> 1 AND EXISTS (SELECT 1 FROM accession_claims ac WHERE ac.copy_barcode = OLD.barcode) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A copy with a claimed accession cannot be hard-deleted';
  END IF;
END//
CREATE TRIGGER `trg_book_copies_claim_identity` BEFORE UPDATE ON `book_copies` FOR EACH ROW
BEGIN
  IF (NEW.id <> OLD.id OR BINARY NEW.barcode <> BINARY OLD.barcode OR NEW.book_id <> OLD.book_id) AND EXISTS (SELECT 1 FROM accession_claims ac WHERE ac.copy_barcode = OLD.barcode AND ac.book_id = OLD.book_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A copy with a claimed accession cannot change physical identity';
  END IF;
END//
DELIMITER ;
-- Section drafts stay private until publication updates the public records.
CREATE TABLE IF NOT EXISTS website_content_drafts (
  section varchar(32) NOT NULL PRIMARY KEY,
  draft_json longtext DEFAULT NULL CHECK (draft_json IS NULL OR json_valid(draft_json)),
  base_json longtext DEFAULT NULL CHECK (base_json IS NULL OR json_valid(base_json)),
  revision int unsigned NOT NULL DEFAULT 0,
  saved_at datetime DEFAULT NULL,
  published_at datetime DEFAULT NULL,
  updated_by bigint unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE website_content_drafts ADD COLUMN IF NOT EXISTS item_meta_json longtext DEFAULT NULL CHECK (item_meta_json IS NULL OR json_valid(item_meta_json));
ALTER TABLE site_content_settings ADD COLUMN IF NOT EXISTS hero_image_alt varchar(500) DEFAULT NULL;
ALTER TABLE academic_subscriptions ADD COLUMN IF NOT EXISTS image_alt varchar(500) DEFAULT NULL;
ALTER TABLE bulletin_posts ADD COLUMN IF NOT EXISTS image_alt varchar(500) DEFAULT NULL, ADD COLUMN IF NOT EXISTS gallery longtext DEFAULT NULL CHECK (gallery IS NULL OR json_valid(gallery));

CREATE TABLE IF NOT EXISTS backup_schedule (
 id tinyint NOT NULL PRIMARY KEY,
 enabled tinyint(1) NOT NULL DEFAULT 0,
 frequency enum('daily','weekly') NOT NULL DEFAULT 'daily',
 hour tinyint NOT NULL DEFAULT 2, weekday tinyint NOT NULL DEFAULT 1,
 next_run datetime DEFAULT NULL,last_run datetime DEFAULT NULL,
 last_result varchar(20) DEFAULT NULL,last_error varchar(255) DEFAULT NULL,
 updated_by bigint unsigned DEFAULT NULL
);
INSERT IGNORE INTO backup_schedule(id) VALUES(1);
ALTER TABLE backup_snapshots MODIFY COLUMN kind enum('manual','scheduled','pre_restore') NOT NULL DEFAULT 'manual';


-- EmailJS account workflows and persistent email delivery
-- Run with a client that stops on errors. DDL auto-commits in MySQL/MariaDB.
-- Preflight does not rewrite historical email addresses.
-- Use one connection and stop on the first error. No DELIMITER command is needed.
-- This temporary unique key rejects duplicate normalized addresses before any DDL.
-- If INSERT reports a duplicate key, resolve those email conflicts before retrying.
DROP TEMPORARY TABLE IF EXISTS email_accounts_preflight;
CREATE TEMPORARY TABLE email_accounts_preflight (
  email varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL PRIMARY KEY
) ENGINE=InnoDB;
INSERT INTO email_accounts_preflight(email)
 SELECT LOWER(TRIM(email)) FROM users
 WHERE deleted_at IS NULL AND NULLIF(TRIM(email), '') IS NOT NULL;
DROP TEMPORARY TABLE email_accounts_preflight;

ALTER TABLE users
  ADD COLUMN setup_pending tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN email_verified_at datetime NULL,
  ADD COLUMN pending_email varchar(255) NULL,
  ADD COLUMN session_version int UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE delivery_outbox MODIFY event_type enum('notification','audit','email') NOT NULL;

CREATE TABLE email_address_claims (
  email varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL PRIMARY KEY,
  user_id bigint UNSIGNED NOT NULL,
  KEY idx_email_claim_user (user_id)
) ENGINE=InnoDB;
INSERT INTO email_address_claims(email,user_id)
 SELECT LOWER(TRIM(email)),id FROM users WHERE deleted_at IS NULL AND NULLIF(TRIM(email),'') IS NOT NULL;

CREATE TABLE account_challenges (
  id char(36) NOT NULL PRIMARY KEY,
  user_id bigint UNSIGNED NOT NULL,
  purpose enum('setup','verify_email','recovery','reset') NOT NULL,
  email varchar(255) NOT NULL,
  secret_hash char(64) NOT NULL,
  attempts tinyint UNSIGNED NOT NULL DEFAULT 0,
  expires_at datetime NOT NULL,
  consumed_at datetime NULL,
  created_at datetime NOT NULL DEFAULT current_timestamp(),
  KEY idx_account_challenges_user (user_id,purpose,consumed_at),
  KEY idx_account_challenges_secret (secret_hash,purpose)
) ENGINE=InnoDB;

-- Operational tables below survive application-data restores.
CREATE TABLE email_request_limits (
  request_key char(64) NOT NULL PRIMARY KEY,
  window_start datetime NOT NULL,
  last_request_at datetime NOT NULL,
  requests int UNSIGNED NOT NULL
) ENGINE=InnoDB;
CREATE TABLE email_deliveries (
  notification_id bigint(20) UNSIGNED DEFAULT NULL,
  KEY idx_email_notification (notification_id,status),
  id char(36) NOT NULL PRIMARY KEY,
  user_id bigint UNSIGNED NOT NULL,
  recipient varchar(255) NOT NULL,
  purpose varchar(50) NOT NULL,
  dedupe_key varchar(191) NOT NULL UNIQUE,
  challenge_id char(36) NULL,
  priority tinyint NOT NULL DEFAULT 0,
  content_encrypted mediumtext NULL,
  context_json json NULL,
  status enum('queued','processing','accepted','failed','cancelled','unknown') NOT NULL DEFAULT 'queued',
  attempts int UNSIGNED NOT NULL DEFAULT 0,
  next_attempt_at datetime NOT NULL DEFAULT current_timestamp(),
  expires_at datetime NOT NULL,
  started_at datetime NULL,
  accepted_at datetime NULL,
  last_error varchar(255) NULL,
  created_at datetime NOT NULL DEFAULT current_timestamp(),
  KEY idx_email_dispatch (status,priority,next_attempt_at)
) ENGINE=InnoDB;
CREATE TABLE email_dispatch_state (
  id tinyint NOT NULL PRIMARY KEY,
  next_send_at datetime(3) NULL
) ENGINE=InnoDB;
INSERT INTO email_dispatch_state(id) VALUES (1);
CREATE TABLE email_quota_usage (
  period_start date NOT NULL PRIMARY KEY,
  period_end date NOT NULL,
  requests_used int UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- Explicit audiences for manual notifications.
CREATE TABLE IF NOT EXISTS notification_recipients (
  notification_id bigint(20) UNSIGNED NOT NULL,
  user_id bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (notification_id,user_id),
  KEY idx_notification_recipients_user (user_id,notification_id),
  CONSTRAINT fk_notification_recipients_notice FOREIGN KEY (notification_id) REFERENCES notifications (id) ON DELETE CASCADE,
  CONSTRAINT fk_notification_recipients_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Apply once before deploying the bulletin discussion and editing release.
ALTER TABLE bulletin_posts
  ADD COLUMN edited_at datetime(3) NULL,
  ADD COLUMN content_revision int unsigned NOT NULL DEFAULT 1;
ALTER TABLE bulletin_comments
  ADD COLUMN parent_id int(11) NULL,
  ADD KEY idx_bulletin_comment_thread (post_id,parent_id,created_at,id),
  ADD CONSTRAINT fk_bulletin_comment_parent FOREIGN KEY (parent_id) REFERENCES bulletin_comments(id);
CREATE TABLE bulletin_reactions (
  post_id int(11) NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  reaction enum('like','helpful','thanks','interested') NOT NULL,
  created_at timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (post_id,user_id),
  KEY idx_bulletin_reaction_kind (post_id,reaction,created_at),
  CONSTRAINT fk_bulletin_reaction_post FOREIGN KEY (post_id) REFERENCES bulletin_posts(id),
  CONSTRAINT fk_bulletin_reaction_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO bulletin_reactions (post_id,user_id,reaction,created_at)
SELECT post_id,user_id,'like',MIN(created_at) FROM bulletin_likes GROUP BY post_id,user_id;

-- Bulletin discussion controls and idempotent comment submissions.
ALTER TABLE bulletin_posts ADD COLUMN comments_locked tinyint(1) NOT NULL DEFAULT 0;
ALTER TABLE bulletin_comments
 ADD COLUMN hidden_at datetime(3) NULL, ADD COLUMN hidden_by bigint(20) unsigned NULL,
 ADD COLUMN pinned_at datetime(3) NULL, ADD COLUMN pinned_by bigint(20) unsigned NULL,
 ADD COLUMN client_request_id varchar(36) NULL,
 ADD UNIQUE KEY uq_bulletin_comment_request (user_id,client_request_id);
CREATE TABLE bulletin_comment_helpful (
 comment_id int(11) NOT NULL,user_id bigint(20) unsigned NOT NULL,created_at timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY(comment_id,user_id),
 CONSTRAINT fk_comment_helpful_comment FOREIGN KEY(comment_id) REFERENCES bulletin_comments(id),
 CONSTRAINT fk_comment_helpful_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Separate public Helpful, private saves, and event planning interest.

ALTER TABLE bulletin_reactions ADD COLUMN consolidated_at datetime(3) NULL;
CREATE TABLE bulletin_helpful (
 post_id int(11) NOT NULL,user_id bigint(20) unsigned NOT NULL,created_at timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY(post_id,user_id),KEY idx_bulletin_helpful_user(user_id,created_at,post_id),
 CONSTRAINT fk_bulletin_helpful_post FOREIGN KEY(post_id) REFERENCES bulletin_posts(id),
 CONSTRAINT fk_bulletin_helpful_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE bulletin_saves (
 post_id int(11) NOT NULL,user_id bigint(20) unsigned NOT NULL,created_at timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY(post_id,user_id),KEY idx_bulletin_saves_user(user_id,created_at,post_id),
 CONSTRAINT fk_bulletin_saves_post FOREIGN KEY(post_id) REFERENCES bulletin_posts(id),
 CONSTRAINT fk_bulletin_saves_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
CREATE TABLE bulletin_event_interest (
 post_id int(11) NOT NULL,user_id bigint(20) unsigned NOT NULL,created_at timestamp NOT NULL DEFAULT current_timestamp(),
 PRIMARY KEY(post_id,user_id),KEY idx_bulletin_event_interest_user(user_id,created_at,post_id),
 CONSTRAINT fk_bulletin_event_interest_post FOREIGN KEY(post_id) REFERENCES bulletin_posts(id),
 CONSTRAINT fk_bulletin_event_interest_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT IGNORE INTO bulletin_helpful(post_id,user_id,created_at) SELECT r.post_id,r.user_id,r.created_at FROM bulletin_reactions r JOIN bulletin_posts p ON p.id=r.post_id WHERE r.consolidated_at IS NULL AND (r.reaction<>'interested' OR p.post_type<>'event');
INSERT IGNORE INTO bulletin_event_interest(post_id,user_id,created_at) SELECT r.post_id,r.user_id,r.created_at FROM bulletin_reactions r JOIN bulletin_posts p ON p.id=r.post_id WHERE r.consolidated_at IS NULL AND r.reaction='interested' AND p.post_type='event';
UPDATE bulletin_reactions SET consolidated_at=UTC_TIMESTAMP(3) WHERE consolidated_at IS NULL;

-- Bulletin review workflow.
ALTER TABLE bulletin_comments ADD COLUMN moderation_status varchar(20) NOT NULL DEFAULT 'published', ADD COLUMN moderation_reason varchar(1000) NULL;
CREATE TABLE IF NOT EXISTS bulletin_moderation_cases (
 id int(11) NOT NULL AUTO_INCREMENT, comment_id int(11) NOT NULL, post_id int(11) NOT NULL,
 status varchar(20) NOT NULL DEFAULT 'open', priority varchar(20) NOT NULL DEFAULT 'normal',
 source varchar(20) NOT NULL DEFAULT 'report', snapshot_text text NOT NULL, screening_reason varchar(500) NULL,
 resolution_reason varchar(1000) NULL, revision int unsigned NOT NULL DEFAULT 1,
 created_at datetime(3) NOT NULL DEFAULT current_timestamp(3), opened_at datetime(3) NOT NULL DEFAULT current_timestamp(3),
 updated_at datetime(3) NOT NULL DEFAULT current_timestamp(3), resolved_at datetime(3) NULL, resolved_by bigint unsigned NULL,
 appealed_at datetime(3) NULL,
 PRIMARY KEY(id), UNIQUE KEY uq_moderation_comment(comment_id), KEY idx_moderation_queue(status,priority,opened_at,id),
 CONSTRAINT fk_moderation_comment FOREIGN KEY(comment_id) REFERENCES bulletin_comments(id),
 CONSTRAINT fk_moderation_post FOREIGN KEY(post_id) REFERENCES bulletin_posts(id),
 CONSTRAINT fk_moderation_reviewer FOREIGN KEY(resolved_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bulletin_comment_reports (
 id bigint unsigned NOT NULL AUTO_INCREMENT, case_id int(11) NOT NULL, reporter_id bigint unsigned NOT NULL,
 reason varchar(40) NOT NULL, details varchar(1000) NULL, created_at datetime(3) NOT NULL DEFAULT current_timestamp(3),
 PRIMARY KEY(id), UNIQUE KEY uq_comment_reporter(case_id,reporter_id),
 CONSTRAINT fk_report_case FOREIGN KEY(case_id) REFERENCES bulletin_moderation_cases(id),
 CONSTRAINT fk_report_user FOREIGN KEY(reporter_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bulletin_moderation_actions (
 id bigint unsigned NOT NULL AUTO_INCREMENT, case_id int(11) NOT NULL, actor_id bigint unsigned NULL,
 action varchar(40) NOT NULL, reason varchar(1000) NOT NULL, created_at datetime(3) NOT NULL DEFAULT current_timestamp(3),
 PRIMARY KEY(id), KEY idx_case_actions(case_id,id),
 CONSTRAINT fk_moderation_action_case FOREIGN KEY(case_id) REFERENCES bulletin_moderation_cases(id),
 CONSTRAINT fk_moderation_action_user FOREIGN KEY(actor_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
