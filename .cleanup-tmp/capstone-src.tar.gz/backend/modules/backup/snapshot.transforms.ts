import { createHash } from "node:crypto";
import registry = require("./snapshot.registry");
import type { SnapshotPayload, SnapshotRow } from "./snapshot.types";

const { APPLICATION_TABLES } = registry;

const SNAPSHOT_VERSION = 25;
const LEGACY_METADATA_KEYS = Object.freeze([
  "category", "edition", "publication_year", "location", "thesis_program",
  "thesis_adviser", "academic_year", "thesis_abstract", "thesis_keywords", "accession_number",
]);

const pad = (value: unknown, length = 2): string => String(value).padStart(length, "0");

function isValidCalendarDate(year: number, month: number, day: number): boolean {
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function invalidDateValue(): Error & { status: number } {
  return Object.assign(new Error("The backup contains an invalid date value."), { status: 400 });
}

function normalizeSqlTemporalValue(value: unknown, columnType: string): string {
  const type = String(columnType).toLowerCase();
  const text = String(value).trim();

  // Preserve canonical SQL values as wall-clock values. Parsing a value such
  // as `2026-07-17 00:00:00` with new Date() depends on the server timezone
  // and can both shift it and let malformed values reach MySQL.
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2})(\.\d{1,6})?)?)?$/);
  if (match) {
    const [, yearText, monthText, dayText, hourText, minuteText, secondText, fraction = ""] = match;
    const year = Number(yearText);
    const month = Number(monthText);
    const day = Number(dayText);
    const hasTime = hourText !== undefined;
    const hour = Number(hourText ?? 0);
    const minute = Number(minuteText ?? 0);
    const second = Number(secondText ?? 0);
    if (!isValidCalendarDate(year, month, day) || hour > 23 || minute > 59 || second > 59) throw invalidDateValue();
    const datePart = `${yearText}-${monthText}-${dayText}`;
    if (type === "date") return datePart;
    if (/^year(?:\(|$)/.test(type)) return yearText;
    if (/^(datetime|timestamp)/.test(type)) {
      const timePart = hasTime ? `${pad(hour)}:${pad(minute)}:${pad(second)}${fraction}` : "00:00:00";
      return `${datePart} ${timePart}`;
    }
  }

  if (/^time(?:\(|$)/.test(type)) {
    // MySQL TIME can contain a sign and values beyond 24 hours. Keep only its
    // documented SQL form; ISO timestamps are handled below.
    if (/^-?\d{1,3}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?$/.test(text)) return text;
    throw invalidDateValue();
  }
  if (/^year(?:\(|$)/.test(type) && /^\d{4}$/.test(text)) return text;

  // Tagged Date objects and uploaded ISO values represent instants, so UTC is
  // the only unambiguous conversion to MySQL's canonical text form.
  if (/T|Z$|[+-]\d{2}:?\d{2}$/.test(text)) return formatDateForMySql(text, type);
  throw invalidDateValue();
}

function formatDateForMySql(isoValue: string, columnType = ""): string {
  const date = new Date(isoValue);
  if (Number.isNaN(date.getTime())) {
    throw invalidDateValue();
  }

  const type = String(columnType).toLowerCase();
  const datePart = `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`;
  const timePart = `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
  if (type === "date") return datePart;
  if (/^time(?:\(|$)/.test(type)) return timePart;
  if (type.startsWith("year")) return String(date.getUTCFullYear());

  const precision = Number(type.match(/\((\d+)\)/)?.[1] ?? 0);
  const fraction = precision > 0
    ? `.${pad(date.getUTCMilliseconds(), 3).padEnd(Math.min(precision, 6), "0").slice(0, Math.min(precision, 6))}`
    : "";
  return `${datePart} ${timePart}${fraction}`;
}

function encodeValue(value: unknown): unknown {
  if (Buffer.isBuffer(value)) return { __backupType: "buffer", data: value.toString("base64") };
  if (value instanceof Date) return { __backupType: "date", data: value.toISOString() };
  return value;
}

function decodeValue(value: unknown, columnType: string | undefined): unknown {
  const taggedValue = value && typeof value === "object" ? value as SnapshotRow : null;
  if (taggedValue?.__backupType === "buffer") return Buffer.from(taggedValue.data as string, "base64");
  if (taggedValue?.__backupType === "date") return formatDateForMySql(taggedValue.data as string, columnType || "");
  const normalizedColumnType = String(columnType).toLowerCase();
  // Every temporal value is normalized and validated before MySQL sees it.
  // This covers both Date objects serialized by mysql2 and plain SQL strings
  // carried in an uploaded snapshot.
  if (typeof value === "string" && /^(date|datetime|timestamp|time|year)/.test(normalizedColumnType)) {
    return normalizeSqlTemporalValue(value, normalizedColumnType);
  }
  // JSON values arrive as objects after an uploaded snapshot is parsed by
  // Express. mysql2 must receive JSON text for a JSON column, not an object
  // coerced to "[object Object]".
  if (normalizedColumnType === "json" && value !== null && value !== undefined) {
    if (typeof value === "string") {
      try { JSON.parse(value); return value; }
      catch { throw Object.assign(new Error("The backup contains invalid JSON data."), { status: 400 }); }
    }
    return JSON.stringify(value);
  }
  return value;
}

function schemaFingerprint(tables: unknown): string {
  return createHash("sha256").update(JSON.stringify(tables) as string).digest("hex");
}

function payloadChecksum(payload: SnapshotPayload): string {
  const { integrity, ...unsigned } = payload;
  return createHash("sha256").update(JSON.stringify(unsigned) as string).digest("hex");
}

function validateBackup(backup: unknown): backup is SnapshotPayload {
  if (!backup || typeof backup !== "object") return false;
  const candidate = backup as SnapshotPayload;
  return candidate.format === "euc-library-backup"
    && Number.isInteger(candidate.version)
    && candidate.tables && typeof candidate.tables === "object";
}

function assertSnapshotIntegrity(backup: SnapshotPayload): void {
  if (backup.version >= 4 && backup.integrity?.checksum !== payloadChecksum(backup)) {
    throw Object.assign(new Error("The backup integrity check failed."), { status: 400 });
  }
  // v3 is the last legacy format that carried a raw schema fingerprint.
  if (backup.version === 3 && (!backup.schema?.tables || backup.schema.fingerprint !== schemaFingerprint(backup.schema.tables))) {
    throw Object.assign(new Error("The backup schema fingerprint is invalid."), { status: 400 });
  }
}

function upgradeV3ToV4(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  for (const field of backup.tables.catalog_schema ?? []) field.scope ||= "shared";
  backup.version = 4;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV4ToV5(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  const schemaMetadataKeys = new Set((backup.tables.catalog_schema ?? [])
    .map((field) => String(field?.key ?? ""))
    .filter((key) => key && !["title", "author", "isbn", "copies"].includes(key)));
  const operationalBookColumns = new Set(["id", "title", "material_type", "metadata", "book_type_id", "author", "isbn", "copies", "created_by", "created_at", "updated_at", "deleted_at", "deleted_by"]);
  const snapshotCustomColumns = new Set((backup.schema?.tables?.books?.columns ?? [])
    .map((column) => String(column?.name ?? ""))
    .filter((key) => key && !operationalBookColumns.has(key)));
  for (const field of backup.tables.catalog_schema ?? []) field.scope ||= "shared";
  for (const book of backup.tables.books ?? []) {
    let metadata = (decodeValue(book.metadata, "json") || {}) as SnapshotRow;
    if (typeof metadata === "string") {
      try { metadata = JSON.parse(metadata) as SnapshotRow; } catch { metadata = {}; }
    }
    for (const key of new Set([...LEGACY_METADATA_KEYS, ...schemaMetadataKeys, ...snapshotCustomColumns])) {
      if (Object.prototype.hasOwnProperty.call(book, key)) {
        if (book[key] !== null && book[key] !== "") metadata[key] = book[key];
        delete book[key];
      }
    }
    book.metadata = JSON.stringify(metadata);
    if (book.material_type === "thesis") { book.book_type_id = null; book.copies = 0; }
  }
  for (const table of APPLICATION_TABLES) backup.tables[table] ??= [];
  if (!backup.tables.library_circulation_settings.length) {
    backup.tables.library_circulation_settings.push({ id: 1, overdue_fine_per_hour: 1 });
  }
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 5;
  delete backup.schema;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV5ToV6(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  // A v5 "ready" reservation did not identify the physical copy it held.
  // Restoring it as ready would promise pickup without protecting inventory,
  // so safely return it to the queue for staff to prepare again.
  for (const reservation of backup.tables.reservations ?? []) {
    if (reservation.status === "ready" && !reservation.reserved_copy_id) {
      reservation.status = "pending";
      reservation.reserved_copy_id = null;
    }
  }
  backup.version = 6;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV6ToV7(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  // v7 introduced the durable actor-aware audit stream. Older snapshots have
  // no equivalent records, but must still restore safely into the new schema.
  for (const table of APPLICATION_TABLES) backup.tables[table] ??= [];
  backup.version = 7;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV7ToV8(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  // Audit history became an append-only system ledger in v8. Existing v7
  // audit rows are intentionally retained in the live database on restore,
  // never replaced by an older snapshot.
  delete backup.tables.audit_events;
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 8;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV8ToV9(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  // The user-guide table was added after v8. Older snapshots have no rows
  // for it, so restore them as an empty table rather than rejecting them.
  backup.tables.user_guide_modules ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 9;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}
function upgradeV9ToV10(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  backup.tables.departments ??= [];
  for (const user of backup.tables.users ?? []) {
    const id = user.student_employee_id;
    if (!id) continue;
    if (["student", "staff", "alumni"].includes(user.role)) user.library_card_number ??= id;
    else if (user.role === "employee") user.employee_number ??= id;
    else user.username ??= id;
  }
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 10;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}
function upgradeV10ToV11(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  // Fine ledger tables did not exist in v10 snapshots. They are populated by
  // the post-restore migration/backfill, never fabricated during restore.
  backup.tables.fine_accounts ??= [];
  backup.tables.fine_ledger_entries ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 11;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}
function upgradeV11ToV12(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  backup.tables.copy_holdings ??= [];
  backup.tables.catalog_settings ??= [{ id: 1, show_unheld_in_opac: 1, updated_by: null }];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 12;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV12ToV13(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  backup.tables.delivery_outbox ??= [];
  for (const borrowing of backup.tables.borrowings ?? []) {
    borrowing.loan_policy_id_snapshot ??= null;
    borrowing.loan_policy_name_snapshot ??= "Unknown historical policy";
  }
  for (const notification of backup.tables.notifications ?? []) notification.delivery_key ??= null;
  // Outbox locks belong to the process that created the snapshot. Pending
  // work is made claimable after restore, while delivered events stay done.
  for (const event of backup.tables.delivery_outbox) {
    if (event.status === "processing") event.status = "pending";
    event.locked_at = null;
  }
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 13;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV13ToV14(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  const claims = backup.tables.accession_claims ?? [];
  const claimNumbers = new Set(claims.map((claim) => String(claim.accession_number)));
  const copiesById = new Map((backup.tables.book_copies ?? []).map((copy) => [Number(copy.id), copy]));
  const booksById = new Map((backup.tables.books ?? []).map((book) => [Number(book.id), book]));
  for (const holding of backup.tables.copy_holdings ?? []) {
    const copy = copiesById.get(Number(holding.copy_id));
    if (!copy || !holding.accession_number || claimNumbers.has(String(holding.accession_number))) continue;
    const book = booksById.get(Number(copy.book_id));
    claims.push({
      accession_number: holding.accession_number,
      copy_barcode: copy.barcode,
      copy_id: Number(copy.id),
      book_id: Number(copy.book_id),
      book_title: String(book?.title ?? `Book ID ${copy.book_id}`),
      claimed_by: holding.created_by ?? holding.updated_by ?? null,
      claimed_at: holding.created_at ?? backup.createdAt,
    });
    claimNumbers.add(String(holding.accession_number));
  }
  backup.tables.accession_claims = claims;
  backup.tables.accession_claim_corrections ??= [];
  for (const table of APPLICATION_TABLES) backup.tables[table] ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 14;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV14ToV15(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  const claims = new Map((backup.tables.accession_claims ?? []).map((claim) => [
    String(claim.accession_number).trim().toLocaleLowerCase("en-US"), claim,
  ]));
  const voids = backup.tables.accession_claim_voids ?? [];
  const voided = new Set(voids.map((entry) => String(entry.accession_number).trim().toLocaleLowerCase("en-US")));
  for (const correction of backup.tables.accession_claim_corrections ?? []) {
    const accessionNumber = String(correction.old_accession_number ?? "").trim();
    const key = accessionNumber.toLocaleLowerCase("en-US");
    if (!accessionNumber || voided.has(key)) continue;
    const claim = claims.get(key);
    if (!claim || String(claim.copy_barcode).toLocaleLowerCase("en-US") !== String(correction.copy_barcode).toLocaleLowerCase("en-US")
      || Number(claim.book_id) !== Number(correction.book_id)) {
      throw Object.assign(new Error("The snapshot has a legacy accession correction without its original permanent claim."), { status: 409 });
    }
    voids.push({
      accession_number: accessionNumber,
      copy_barcode: claim.copy_barcode,
      copy_id: Number(claim.copy_id),
      book_id: Number(claim.book_id),
      book_title: claim.book_title,
      reason: `Legacy correction: ${correction.reason ?? "no reason recorded"}`.slice(0, 500),
      voided_by: correction.corrected_by ?? null,
      voided_at: correction.corrected_at ?? backup.createdAt,
    });
    voided.add(key);
  }
  backup.tables.accession_claim_voids = voids;
  for (const table of APPLICATION_TABLES) backup.tables[table] ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 15;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV15ToV16(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  backup.tables.website_content_drafts ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version = 16;
  backup.integrity = { algorithm: "sha256", checksum: payloadChecksum(backup) };
  return backup;
}

function upgradeV16ToV17(backup:SnapshotPayload):SnapshotPayload {
 assertSnapshotIntegrity(backup);
 for(const row of backup.tables.website_content_drafts||[])row.item_meta_json??=null;
 for(const row of backup.tables.site_content_settings||[])row.hero_image_alt??=null;
 for(const row of backup.tables.academic_subscriptions||[])row.image_alt??=null;
 for(const row of backup.tables.bulletin_posts||[]){row.image_alt??=null;row.gallery??="[]";}
 backup.version=17;backup.integrity={algorithm:"sha256",checksum:payloadChecksum(backup)};return backup;
}
function upgradeV17ToV18(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  for (const user of backup.tables.users ?? []) { user.setup_pending ??= 0; user.email_verified_at ??= null; user.pending_email ??= null; user.session_version ??= 0; }
  backup.version=18; backup.integrity={algorithm:"sha256",checksum:payloadChecksum(backup)}; return backup;
}

// Each supported snapshot version advances through one reviewed transformer.
function upgradeV18ToV19(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  for (const row of backup.tables.notifications ?? []) {row.email_requested??=0;row.email_batch_id??=null;row.email_expires_at??=null;}
  backup.version=19;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV19ToV20(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  for(const row of backup.tables.notifications ?? []){row.image_url??=null;row.image_public_id??=null;row.image_alt??=null;}
  backup.version=20;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV20ToV21(backup: SnapshotPayload): SnapshotPayload {
  assertSnapshotIntegrity(backup);
  backup.tables.notification_recipients ??= [];
  backup.tableManifest = Object.keys(backup.tables).sort();
  backup.version=21;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV21ToV22(backup: SnapshotPayload): SnapshotPayload {
 assertSnapshotIntegrity(backup);
 for(const row of backup.tables.bulletin_posts||[]){row.edited_at??=null;row.content_revision??=1;}
 for(const row of backup.tables.bulletin_comments||[])row.parent_id??=null;
 const seen=new Set<string>();backup.tables.bulletin_reactions=(backup.tables.bulletin_likes||[]).filter(row=>{const key=`${row.post_id}:${row.user_id}`;if(seen.has(key))return false;seen.add(key);return true;}).map(row=>({post_id:row.post_id,user_id:row.user_id,reaction:'like',created_at:row.created_at}));
 backup.tableManifest=Object.keys(backup.tables).sort();backup.version=22;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV22ToV23(backup: SnapshotPayload): SnapshotPayload {
 assertSnapshotIntegrity(backup);
 for(const row of backup.tables.bulletin_posts||[])row.comments_locked??=0;
 for(const row of backup.tables.bulletin_comments||[])for(const field of ['hidden_at','hidden_by','pinned_at','pinned_by','client_request_id'])row[field]??=null;
 backup.tables.bulletin_comment_helpful??=[];
 backup.tableManifest=Object.keys(backup.tables).sort();backup.version=23;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV23ToV24(backup: SnapshotPayload): SnapshotPayload {
 assertSnapshotIntegrity(backup);
 backup.tables.bulletin_helpful??=[];backup.tables.bulletin_saves??=[];backup.tables.bulletin_event_interest??=[];
 const eventIds=new Set((backup.tables.bulletin_posts||[]).filter(row=>row.post_type==='event').map(row=>String(row.id)));
 for(const row of backup.tables.bulletin_reactions||[]){
  if(row.consolidated_at)continue;
  const target=row.reaction==='interested'&&eventIds.has(String(row.post_id))?backup.tables.bulletin_event_interest:backup.tables.bulletin_helpful;
  if(!target.some(item=>String(item.post_id)===String(row.post_id)&&String(item.user_id)===String(row.user_id)))target.push({post_id:row.post_id,user_id:row.user_id,created_at:row.created_at});
  row.consolidated_at=row.created_at||'1970-01-01 00:00:00';
 }
 backup.tableManifest=Object.keys(backup.tables).sort();backup.version=24;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
function upgradeV24ToV25(backup: SnapshotPayload): SnapshotPayload {
 assertSnapshotIntegrity(backup);
 for(const row of backup.tables.bulletin_comments||[]){row.moderation_status??='published';row.moderation_reason??=null;}
 for(const table of ['bulletin_moderation_cases','bulletin_comment_reports','bulletin_moderation_actions'])backup.tables[table]??=[];
 backup.tableManifest=Object.keys(backup.tables).sort();backup.version=25;backup.integrity={algorithm:'sha256',checksum:payloadChecksum(backup)};return backup;
}
const SNAPSHOT_TRANSFORMERS = new Map<number, (backup: SnapshotPayload) => SnapshotPayload>([
  [3, upgradeV3ToV4],
  [4, upgradeV4ToV5],
  [5, upgradeV5ToV6],
  [6, upgradeV6ToV7],
  [7, upgradeV7ToV8],
  [8, upgradeV8ToV9],
  [9, upgradeV9ToV10],
  [10, upgradeV10ToV11],
  [11, upgradeV11ToV12],
  [12, upgradeV12ToV13],
  [13, upgradeV13ToV14],
  [14, upgradeV14ToV15],
  [15, upgradeV15ToV16],
  [16, upgradeV16ToV17],
  [17, upgradeV17ToV18],
  [18, upgradeV18ToV19],
  [19, upgradeV19ToV20],
  [20, upgradeV20ToV21],
  [21, upgradeV21ToV22],
  [22, upgradeV22ToV23],
  [23, upgradeV23ToV24],
  [24, upgradeV24ToV25],
]);

function upgradeBackup(backup: SnapshotPayload): SnapshotPayload {
  if (backup.version > SNAPSHOT_VERSION) {
    throw Object.assign(new Error(`Snapshot version ${backup.version} was created by a newer release and cannot be restored safely.`), { status: 409 });
  }
  while (backup.version !== SNAPSHOT_VERSION) {
    const transformer = SNAPSHOT_TRANSFORMERS.get(backup.version);
    if (!transformer) throw Object.assign(new Error(`Snapshot version ${backup.version} is not supported by this release.`), { status: 409 });
    backup = transformer(backup);
  }
  assertSnapshotIntegrity(backup);
  return backup;
}

export = {
  SNAPSHOT_VERSION,
  encodeValue,
  decodeValue,
  payloadChecksum,
  validateBackup,
  upgradeBackup,
};
