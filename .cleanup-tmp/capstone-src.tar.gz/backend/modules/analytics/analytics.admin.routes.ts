const express = require("express");
const { authMiddleware } = require("../auth/auth.middleware");
const { limiters } = require("../../middlewares/rateLimiter");
const { handleGetAuditLog, handleGetAuditLogMeta, handleGetDashboardOverview, handleCreateAiAnalyticsReport } = require("./analytics.controller");

const router = express.Router();

router.get(
  "/dashboard",
  authMiddleware(["staff", "admin", "super_admin"]),
  handleGetDashboardOverview
);

router.post(
  "/dashboard/ai-report",
  authMiddleware(["staff", "admin", "super_admin"]),
  limiters.aiReport,
  handleCreateAiAnalyticsReport
);

router.get(
  "/dashboard/audit",
  authMiddleware(["super_admin"]),
  handleGetAuditLog
);

router.get(
  "/dashboard/audit/meta",
  authMiddleware(["super_admin"]),
  handleGetAuditLogMeta
);

router.post("/dashboard/audit/export",authMiddleware(["super_admin"]),require("./audit.export").handleExport);
module.exports = router;
