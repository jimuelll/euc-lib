import type { Request, RequestHandler } from "express";
import auth = require("./jwt.util");
import { operationsRequestAllowed } from "./operations-access";

interface AuthTokenPayload {
  id: number;
  role: string;
  iat?: number;
  must_change_password?: boolean;
  [claim: string]: unknown;
}
type AuthenticatedRequest = Request & { user?: AuthTokenPayload };
type RefreshLimitRequest = Request & { rateLimitUserId?: number; cookies?: Record<string, string | undefined> };

const cookies = require("./auth.cookies") as { getRefreshTokenFromCookies: (req: RefreshLimitRequest) => string | null };

const { isAccessTokenCurrent, isUserAccessActive } = require("./authSession.service") as {
  isAccessTokenCurrent: (payload: AuthTokenPayload) => Promise<boolean>;
  isUserAccessActive: (userId: number) => Promise<boolean>;
};

function authMiddleware(roles: string[] = []): RequestHandler {
  return async (req, res, next) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) {
        res.status(401).json({ message: "Login required to use this feature" });
        return;
      }

      const token = authHeader.split(" ")[1];
      const payload = auth.verifyAccessToken(token) as AuthTokenPayload;
      if (!(await isAccessTokenCurrent(payload))) {
        res.status(401).json({ message: "Your session ended. Please sign in again." });
        return;
      }
      if (!(await isUserAccessActive(payload.id))) {
        res.status(401).json({ message: "Your account is inactive. Please contact the library." });
        return;
      }

      if (!operationsRequestAllowed(payload.role, req.method, req.originalUrl) || roles.length && !roles.includes(payload.role)) {
        res.status(403).json({ message: "Forbidden" });
        return;
      }

      (req as AuthenticatedRequest).user = payload;
      next();
    } catch {
      res.status(401).json({ message: "Your session is invalid. Please log in again." });
    }
  };
}

function optionalAuthMiddleware(): RequestHandler {
  return async (req, _res, next) => {
    const authenticatedRequest = req as AuthenticatedRequest;
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return next();

      const token = authHeader.split(" ")[1];
      if (!token) return next();

      const payload = auth.verifyAccessToken(token) as AuthTokenPayload;
      authenticatedRequest.user = (await isAccessTokenCurrent(payload)) && (await isUserAccessActive(payload.id))
        ? payload
        : undefined;
    } catch {
      authenticatedRequest.user = undefined;
    }

    next();
  };
}

// A correctly signed refresh token lets the refresh-account limiter key by
// account without trusting an unsigned cookie claim. Session validity and
// rotation remain the responsibility of the refresh controller.
const createRefreshIdentityMiddleware = (
  verifyRefreshToken: (token: string) => AuthTokenPayload,
  getRefreshToken: (req: RefreshLimitRequest) => string | null,
): RequestHandler => (req, _res, next) => {
  const refreshToken = getRefreshToken(req as RefreshLimitRequest);
  if (refreshToken) {
    try {
      const payload = verifyRefreshToken(refreshToken);
      if (Number.isSafeInteger(payload.id) && payload.id > 0) {
        (req as RefreshLimitRequest).rateLimitUserId = payload.id;
      }
    } catch {
      // Invalid tokens continue through the IP limit and normal refresh error path.
    }
  }
  next();
};

const identifyRefreshLimitAccount = createRefreshIdentityMiddleware(
  (token) => auth.verifyRefreshToken(token) as AuthTokenPayload,
  cookies.getRefreshTokenFromCookies,
);

export = { authMiddleware, optionalAuthMiddleware, identifyRefreshLimitAccount, createRefreshIdentityMiddleware };
