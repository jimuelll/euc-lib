const express = require("express");
const {
  handleUserBorrowing,
  handleResetOperationsPassword,
  handleAvailability,
  handleAccountEmailStatus,
  handleCreateUser,
  handleDeleteUser,
  handleUpdateUser,
  handleSearchUsers,
  handleRestoreUser,
  handleQueryToolsSearch,
} = require("./admin.controller");
const { authMiddleware } = require("../auth/auth.middleware");
const router = express.Router();
const staffOrAbove = authMiddleware(["staff", "admin", "super_admin"]);
router.get("/users/:student_employee_id/borrowing", staffOrAbove, handleUserBorrowing);
router.post("/users/availability", staffOrAbove, handleAvailability);
router.get("/users/:student_employee_id/account-email", staffOrAbove, handleAccountEmailStatus);
router.post("/users/:student_employee_id/reset-password", authMiddleware(["admin", "super_admin"]), require("../../middlewares/rateLimiter").limiters.passwordChange, handleResetOperationsPassword);
router.post("/users", staffOrAbove, handleCreateUser);
router.delete("/users/:student_employee_id", staffOrAbove, handleDeleteUser);
router.put("/users/:student_employee_id", staffOrAbove, handleUpdateUser);
router.get("/users", staffOrAbove, handleSearchUsers);
router.patch("/users/:student_employee_id/restore", staffOrAbove, handleRestoreUser);
router.get("/query-tools", staffOrAbove, handleQueryToolsSearch);
module.exports = router;
