import type { PoolConnection, RowDataPacket } from "mysql2/promise";
import repository = require("./borrowing.repository");
import notifications = require("../notifications/notifications.service");
import librarySettings = require("../library-settings/library-settings.service");
import fine = require("./fine-calculation");
import { addLibraryCalendarDays, libraryDateKey } from "../time/library-time";

interface BorrowingRow extends RowDataPacket {
  id: number;
  status: string;
  due_date: Date | string | null;
  user_id?: number;
  title?: string;
  borrowed_at?: Date | string | null;
  returned_at?: Date | string | null;
  fine_per_hour?: number | string | null;
  fine_interval?: string | null;
  initial_fine?: number | string | null;
  borrowing_archived_at?: Date | string | null;
  last_overdue_notification_at?: Date | string | null;
  unsettled_amount?: number | string;
}
interface OverdueBorrowingRow extends BorrowingRow {
  user_id: number;
  title: string;
}
interface FineBalance {
  fineAmount: number;
  paidAmount: number;
  adjustedAmount: number;
  balance: number;
}
interface FineLedger {
  balancesForBorrowings: (ids: number[], conn?: PoolConnection) => Promise<Map<number, FineBalance>>;
  assessBorrowing: (row: BorrowingRow, conn: PoolConnection) => Promise<FineCalculationResult>;
}
interface BorrowingRepository {
  getConnection: () => Promise<PoolConnection>;
  findOverdueCandidates: (conn: PoolConnection) => Promise<OverdueBorrowingRow[]>;
  markOverdue: (borrowingId: number, conn: PoolConnection) => Promise<void>;
  markOverdueNotificationSent: (borrowingId: number, conn: PoolConnection) => Promise<void>;
  findBorrowingsForFineDetails: (userId: number | null, conn?: PoolConnection) => Promise<BorrowingRow[]>;
}

const borrowingRepository = repository as unknown as BorrowingRepository;
const fineLedger = require("./fine-ledger.service") as FineLedger;
type FineCalculationInput = Parameters<typeof fine.calculateFine>[0];
type FineCalculationResult = ReturnType<typeof fine.calculateFine>;
const HOUR_MS = 60 * 60 * 1000;
const OVERDUE_REMINDER_INTERVAL_MS = HOUR_MS;
let ensuredBorrowingPaymentColumns = false;

const ensureBorrowingPaymentColumns = async (): Promise<void> => {
  if (ensuredBorrowingPaymentColumns) return;
  // Settlement columns are guaranteed by the migration baseline. Request handlers must never change schema.
  ensuredBorrowingPaymentColumns = true;
};

const calculateDueDateWithHolidays = async (borrowedAt: Date | string | number, daysAllowed: number, conn?: PoolConnection): Promise<Date> => {
  const holidayDateSet = await librarySettings.getHolidayDateSet(conn);
  let dueDate = new Date(borrowedAt);
  let countedDays = 0;
  while (countedDays < daysAllowed) {
    dueDate = addLibraryCalendarDays(dueDate, 1);
    if (holidayDateSet.has(libraryDateKey(dueDate))) continue;
    countedDays += 1;
  }
  return dueDate;
};

interface FinePolicy extends FineCalculationInput {
  settledAmount?: number | string;
  finePerHour: unknown;
}
type FineDetails = FineCalculationResult & { settledAmount: number; unsettledAmount: number };

const getFineDetails = ({ settledAmount = 0, ...policy }: FinePolicy): FineDetails => {
  const calculated = fine.calculateFine(policy);
  return {
    ...calculated,
    settledAmount: fine.roundCurrency(settledAmount),
    unsettledAmount: fine.roundCurrency(Math.max(calculated.fineAmount - Number(settledAmount), 0)),
  };
};

const mapBorrowingsWithFineDetails = async <TRow extends BorrowingRow>(rows: TRow[], conn?: PoolConnection) => {
  await ensureBorrowingPaymentColumns();
  const settings = await librarySettings.getSettings(conn);
  const now = new Date();
  const balances = await fineLedger.balancesForBorrowings(rows.map((row) => row.id), conn);
  return rows.map((row) => {
    const { isOverdue, hoursOverdue } = getFineDetails({
      dueDate: row.due_date,
      finePerHour: row.fine_per_hour ?? settings.overdue_fine_per_hour,
      fineInterval: row.fine_interval ?? "hour",
      initialFine: row.initial_fine ?? 0,
      now,
      returnedAt: row.returned_at,
    });
    const balance = balances.get(Number(row.id));
    if (!balance) throw new Error(`Fine ledger is missing loan #${row.id}. Apply and backfill the fine-ledger migration.`);
    return {
      ...row,
      is_archived: Boolean(row.borrowing_archived_at),
      hours_overdue: hoursOverdue,
      fine_amount: balance.fineAmount,
      settled_amount: fine.roundCurrency(balance.paidAmount + balance.adjustedAmount),
      unsettled_amount: balance.balance,
      // The current library rate is only a fallback for legacy loans. Newer
      // borrowings keep the terms that were saved at checkout.
      fine_per_hour: row.fine_per_hour ?? settings.overdue_fine_per_hour,
      fine_interval: row.fine_interval ?? "hour",
      initial_fine: row.initial_fine ?? 0,
      status: row.status === "returned" ? row.status : (isOverdue ? "overdue" : row.status),
    };
  });
};

const syncOverdueBorrowingsInTransaction = async (conn: PoolConnection): Promise<void> => {
  await ensureBorrowingPaymentColumns();
  const settings = await librarySettings.getSettings(conn);
  const rows = await borrowingRepository.findOverdueCandidates(conn);
  for (const row of rows) {
    const { isOverdue } = await fineLedger.assessBorrowing({ ...row, fine_per_hour: row.fine_per_hour ?? settings.overdue_fine_per_hour }, conn);
    if (!isOverdue) continue;
    if (row.status !== "overdue") await borrowingRepository.markOverdue(row.id, conn);
    const balance = (await fineLedger.balancesForBorrowings([row.id], conn)).get(Number(row.id));
    const unsettledAmount = balance?.balance ?? 0;
    const shouldNotifyAgain = unsettledAmount > 0 && (!row.last_overdue_notification_at || (Date.now() - new Date(row.last_overdue_notification_at).getTime()) >= OVERDUE_REMINDER_INTERVAL_MS);
    if (shouldNotifyAgain) {
      await notifications.enqueueNotification(conn, {
        type: "overdue_fine",
        title: "Borrowed book is overdue",
        body: `"${row.title}" is overdue. Current unsettled balance: PHP ${unsettledAmount.toFixed(2)}. The fine continues under the terms saved on this loan until it is settled or returned.`,
        href: "/my-library",
        audienceType: "user",
        audienceUserId: row.user_id,
        sourceType: "borrowing",
        sourceId: row.id,
        replaceExisting: true,
      });
      await borrowingRepository.markOverdueNotificationSent(row.id, conn);
    }
  }
};

const syncOverdueBorrowings = async (conn: PoolConnection | null = null): Promise<void> => {
  if (conn) return syncOverdueBorrowingsInTransaction(conn);
  const connection = await borrowingRepository.getConnection();
  try {
    await connection.beginTransaction();
    await syncOverdueBorrowingsInTransaction(connection);
    await connection.commit();
  } catch (error: unknown) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

async function listUnsettledBorrowings({ userId = null, limit = null, page = null }: {
  userId?: number | null;
  limit?: number | null;
  page?: number | null;
} = {}, conn?: PoolConnection) {
  await ensureBorrowingPaymentColumns();
  const rows = await borrowingRepository.findBorrowingsForFineDetails(userId, conn);
  const mappedRows = await mapBorrowingsWithFineDetails(rows, conn);
  const unsettledRows = mappedRows.filter((row) => Number(row.unsettled_amount || 0) > 0).sort((left, right) => {
    const leftDate = new Date(left.returned_at ?? left.due_date ?? left.borrowed_at ?? 0).getTime();
    const rightDate = new Date(right.returned_at ?? right.due_date ?? right.borrowed_at ?? 0).getTime();
    return leftDate - rightDate;
  });
  const safeLimit = typeof limit === "number" ? Math.max(1, limit) : null;
  const safePage = Number.isFinite(Number(page)) ? Math.max(1, Number(page)) : null;
  const limitedRows = safeLimit ? unsettledRows.slice(safePage ? (safePage - 1) * safeLimit : 0, safePage ? safePage * safeLimit : safeLimit) : unsettledRows;
  const result: {
    rows: typeof limitedRows;
    summary: { total_records: number; affected_users: number; total_unsettled_amount: number };
    pagination?: { page: number; limit: number; total: number; totalPages: number };
  } = {
    rows: limitedRows,
    summary: {
      total_records: unsettledRows.length,
      affected_users: new Set(unsettledRows.map((row) => row.user_id)).size,
      total_unsettled_amount: fine.roundCurrency(unsettledRows.reduce((sum, row) => sum + Number(row.unsettled_amount || 0), 0)),
    },
  };
  if (safePage && safeLimit) result.pagination = { page: safePage, limit: safeLimit, total: unsettledRows.length, totalPages: Math.ceil(unsettledRows.length / safeLimit) };
  return result;
}

export = { ensureBorrowingPaymentColumns, calculateDueDateWithHolidays, getFineDetails, mapBorrowingsWithFineDetails, syncOverdueBorrowings, listUnsettledBorrowings };
