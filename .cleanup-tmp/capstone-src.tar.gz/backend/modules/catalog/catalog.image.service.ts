import type { PoolConnection, RowDataPacket } from "mysql2/promise";

const { randomUUID } = require("node:crypto");
const { v2: cloudinary } = require("cloudinary");
const repository = require("./catalog.repository");
const snapshotRepository = require("../backup/backup.repository");
const transactionalAudit = require("../analytics/transactional-audit");

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
interface CatalogImageFile {
  buffer: Buffer;
  size: number;
  mimetype: string;
}
interface UploadedImage {
  image_url: string;
  image_public_id: string;
  bytes?: number;
  width?: number;
  height?: number;
}
interface BookImageRow extends RowDataPacket {
  id: number;
  title: string;
  material_type: string;
  image_url: string | null;
  image_public_id: string | null;
}
const IMAGE_SIGNATURES: Record<string, (buffer: Buffer) => boolean> = {
  "image/jpeg": (buffer) => buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff,
  "image/png": (buffer) => buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
  "image/webp": (buffer) => buffer.length >= 12 && buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP",
};

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const httpError = (message: string, status: number) => Object.assign(new Error(message), { status });

function validateCatalogImage(file: CatalogImageFile | null | undefined): asserts file is CatalogImageFile {
  if (!file || !Buffer.isBuffer(file.buffer)) throw httpError("Choose an image to upload", 400);
  if (file.size > MAX_IMAGE_BYTES || file.buffer.length > MAX_IMAGE_BYTES) throw httpError("Images must be 5 MB or smaller", 413);
  const signatureMatches = IMAGE_SIGNATURES[file.mimetype]?.(file.buffer);
  if (!signatureMatches) throw httpError("Upload a valid JPG, PNG, or WebP image", 415);
}

function requireCloudinary() {
  if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
    throw httpError("Cloudinary image storage is not configured", 503);
  }
}

function uploadBuffer(buffer: Buffer, bookId: number): Promise<UploadedImage> {
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream({
      folder: "library/catalog/books",
      resource_type: "image",
      public_id: `book-${bookId}-${randomUUID()}`,
      overwrite: false,
      tags: ["catalog-book-cover"],
    }, (error: any, result: any) => {
      if (error) reject(error);
      else if (!result?.secure_url || !result?.public_id) reject(new Error("Cloudinary did not return an image URL"));
      else resolve({ image_url: result.secure_url, image_public_id: result.public_id, ...(typeof result.bytes === "number" ? { bytes: result.bytes } : {}), ...(typeof result.width === "number" ? { width: result.width } : {}), ...(typeof result.height === "number" ? { height: result.height } : {}) });
    });
    stream.end(buffer);
  });
}

async function destroyImage(publicId: string | null | undefined): Promise<void> {
  if (!publicId) return;
  try {
    await cloudinary.uploader.destroy(publicId, { resource_type: "image" });
  } catch (error: any) {
    console.warn("[catalog] Cloudinary image cleanup failed:", error.message);
  }
}

async function destroyImageIfUnreferenced(publicId: string | null | undefined): Promise<void> {
  if (!publicId) return;
  try {
    if (await snapshotRepository.isBookImageReferenced(publicId)) return;
    await destroyImage(publicId);
  } catch (error: any) {
    // A failed reference check must never make a restorable snapshot lose its image.
    console.warn("[catalog] Could not check snapshot references; preserving Cloudinary image:", error.message);
  }
}

async function uploadBookImage(bookId: number, file: CatalogImageFile, actorId: number | null = null): Promise<UploadedImage> {
  validateCatalogImage(file);
  const conn: PoolConnection = await repository.getConnection();
  let uploaded = null;
  let oldPublicId: string | null = null;
  try {
    await conn.beginTransaction();
    const [[book]] = await conn.query<BookImageRow[]>(
      "SELECT id, title, material_type, image_url, image_public_id FROM books WHERE id = ? AND deleted_at IS NULL FOR UPDATE",
      [bookId],
    );
    if (!book) throw httpError("Catalog record not found", 404);
    if (book.material_type !== "book") throw httpError("Theses always use the generic thesis image", 400);
    requireCloudinary();

    uploaded = await uploadBuffer(file.buffer, bookId);
    oldPublicId = book.image_public_id;
    await conn.query("UPDATE books SET image_url = ?, image_public_id = ? WHERE id = ? AND deleted_at IS NULL", [uploaded.image_url, uploaded.image_public_id, bookId]);
    await transactionalAudit.enqueueTransactionalAudit(conn, {
      actorId,
      route: `/api/admin/books/${bookId}/image`,
      description: `Updated cover image for “${book.title}”`,
      before: { cover_image: book.image_url ? "set" : "not set" },
      after: { cover_image: "set" },
    });
    await conn.commit();
  } catch (error: any) {
    await conn.rollback();
    if (uploaded) await destroyImage(uploaded.image_public_id);
    throw error;
  } finally {
    conn.release();
  }
  const completedUpload = uploaded as UploadedImage;
  if (oldPublicId && oldPublicId !== completedUpload.image_public_id) await destroyImageIfUnreferenced(oldPublicId);
  return completedUpload;
}

async function removeBookImage(bookId: number, actorId: number | null = null): Promise<void> {
  const conn: PoolConnection = await repository.getConnection();
  let oldPublicId: string | null = null;
  try {
    await conn.beginTransaction();
    const [[book]] = await conn.query<BookImageRow[]>(
      "SELECT id, title, material_type, image_url, image_public_id FROM books WHERE id = ? AND deleted_at IS NULL FOR UPDATE",
      [bookId],
    );
    if (!book) throw httpError("Catalog record not found", 404);
    if (book.material_type !== "book") throw httpError("Theses always use the generic thesis image", 400);
    oldPublicId = book.image_public_id;
    if (oldPublicId) requireCloudinary();
    if (oldPublicId || book.image_url) {
      await conn.query("UPDATE books SET image_url = NULL, image_public_id = NULL WHERE id = ? AND deleted_at IS NULL", [bookId]);
      await transactionalAudit.enqueueTransactionalAudit(conn, {
        actorId,
        route: `/api/admin/books/${bookId}/image`,
        action: "updated",
        description: `Removed cover image for “${book.title}”`,
        before: { cover_image: "set" },
        after: { cover_image: "not set" },
      });
    }
    await conn.commit();
  } catch (error: any) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
  await destroyImageIfUnreferenced(oldPublicId);
}

async function getImageMetadata(bookId: number) {
  const conn: PoolConnection = await repository.getConnection();
  let publicId: string | null = null;
  try {
    const [[book]] = await conn.query<BookImageRow[]>("SELECT id, image_public_id FROM books WHERE id = ?", [bookId]);
    if (!book) throw httpError("Catalog record not found", 404);
    publicId = book.image_public_id;
  } finally { conn.release(); }
  if (!publicId) return { bytes: null, width: null, height: null };
  requireCloudinary();
  const image = await cloudinary.api.resource(publicId, { resource_type: "image" });
  return { bytes: image.bytes ?? null, width: image.width ?? null, height: image.height ?? null };
}

async function importIsbnImage(bookId: number, isbn: unknown, actorId: number | null = null) {
  const { lookupIsbn } = require("./catalog.query.service");
  const metadata = await lookupIsbn(isbn);
  if (!metadata.cover_url) throw httpError("No cover was available from the ISBN source", 404);
  let url = new URL(metadata.cover_url);
  let response: Response | undefined;
  const signal = AbortSignal.timeout(10000);
  for (let redirects = 0; redirects <= 3; redirects++) {
    if (url.protocol !== "https:" || !["covers.openlibrary.org", "books.google.com", "books.googleusercontent.com"].includes(url.hostname) || url.username || url.password || url.port) throw httpError("Unsupported cover source", 400);
    response = await fetch(url, { redirect: "manual", signal });
    if (![301, 302, 303, 307, 308].includes(response.status)) break;
    const location = response.headers.get("location");
    if (!location || redirects === 3) throw httpError("Too many cover redirects", 502);
    url = new URL(location, url);
  }
  if (!response) throw httpError("Could not download the ISBN cover", 502);
  if (!response.ok || !response.body) throw httpError("Could not download the ISBN cover", 502);
  const contentLength = Number(response.headers.get("content-length") || 0);
  if (contentLength > MAX_IMAGE_BYTES) throw httpError("Images must be 5 MB or smaller", 413);
  const chunks: Uint8Array[] = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > MAX_IMAGE_BYTES) throw httpError("Images must be 5 MB or smaller", 413);
    chunks.push(chunk);
  }
  const file = { buffer: Buffer.concat(chunks), size, mimetype: (response.headers.get("content-type") || "").split(";")[0].toLowerCase() };
  return uploadBookImage(bookId, file, actorId);
}

export = { MAX_IMAGE_BYTES, validateCatalogImage, uploadBookImage, removeBookImage, getImageMetadata, importIsbnImage };
