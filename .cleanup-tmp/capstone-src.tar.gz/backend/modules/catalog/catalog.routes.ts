import type { Request, RequestHandler } from "express";

const express    = require("express");
const router     = express.Router();
const controller = require("./catalog.controller");
const { parseCatalogImage } = require("./catalog.image.middleware");
const { limiters } = require("../../middlewares/rateLimiter");
const {
  requireSuperAdminRole,
  requireCatalogRole,
  validateSchemaPayload,
  validateBookId,
  validateBarcode,
  validateBookTypeId,
  validateCreateBookPayload,
  validateUpdateBookPayload,
} = require("./catalog.middleware");

const validateCopyIdParam: RequestHandler = (req, res, next) => {
  const copyId = Number(req.params.copyId);
  if (!Number.isSafeInteger(copyId) || copyId < 1) return res.status(400).json({ message: "Invalid copy ID" });
  (req.params as unknown as Record<string, string | number>).copyId = copyId;
  next();
};

router.get   ("/catalog-schema", requireCatalogRole,                       controller.getSchema);
router.get("/catalog-schema/impact", requireSuperAdminRole, controller.getConfigurationImpact);
router.get   ("/catalog-settings", requireCatalogRole, controller.getCatalogSettings);
router.put   ("/catalog-settings", requireSuperAdminRole, controller.updateCatalogSettings);
router.get   ("/book-types", requireCatalogRole, controller.getBookTypes);
router.post  ("/book-types", requireSuperAdminRole, controller.createBookType);
router.put   ("/book-types/:id", requireSuperAdminRole, controller.updateBookType);
router.delete("/book-types/:id", requireSuperAdminRole, validateBookTypeId, controller.deleteBookType);
router.put   ("/catalog-schema", requireSuperAdminRole, validateSchemaPayload, controller.updateSchema);

router.get   ("/books",          requireCatalogRole,                       controller.getBooks);
router.get   ("/books/isbn-check/:isbn", requireCatalogRole, controller.checkIsbn);
router.get   ("/books/isbn/:isbn", requireCatalogRole, limiters.isbnLookup, controller.lookupIsbn);
router.post  ("/books",          requireCatalogRole, validateCreateBookPayload,           controller.createBook);
router.post  ("/books/:id/image", requireCatalogRole, limiters.imageUpload, validateBookId, parseCatalogImage, controller.uploadBookImage);
router.get   ("/books/:id/image/metadata", requireCatalogRole, validateBookId, controller.getImageMetadata);
router.post  ("/books/:id/image/isbn", requireCatalogRole, limiters.imageUpload, validateBookId, controller.importIsbnImage);
router.delete("/books/:id/image", requireCatalogRole, validateBookId, controller.removeBookImage);
router.put   ("/books/:id",      requireCatalogRole, validateBookId, validateUpdateBookPayload, controller.updateBook);
router.delete("/books/:id",      requireCatalogRole, validateBookId,        controller.deleteBook);

router.post  ("/books/:id/copies", requireCatalogRole, validateBookId, controller.addBookCopies);
router.post  ("/books/:id/accessions", requireCatalogRole, validateBookId, controller.assignAccessionRange);
router.get   ("/books/:id/copies",           requireCatalogRole, validateBookId,  controller.getBookCopies);
router.get   ("/books/:id/holdings",          requireCatalogRole, validateBookId, controller.getBookHoldings);
router.get   ("/holding-options", requireCatalogRole, controller.getHoldingOptions);
router.get   ("/holdings",                    requireCatalogRole, controller.getHoldings);
router.put   ("/copies/:copyId/holding",      requireCatalogRole, validateCopyIdParam, controller.updateHolding);
router.post  ("/copies/:copyId/holding/void-accession", requireSuperAdminRole, validateCopyIdParam, controller.voidAccession);
router.post  ("/copies/:copyId/retire", requireCatalogRole, validateCopyIdParam, controller.retireCopy);
router.post  ("/copies/:copyId/restore", requireCatalogRole, validateCopyIdParam, controller.restoreCopy);

// Barcode image + copy lookup (used at the desk / scanner)
router.get   ("/copies/:barcode/barcode-png", requireCatalogRole, validateBarcode, controller.getBarcodePng);
router.get   ("/copies/:barcode",             requireCatalogRole, validateBarcode, controller.getCopyByBarcode);
router.patch ("/copies/:copyId", requireCatalogRole, validateCopyIdParam, controller.updateCopyCondition);

router.get("/catalogue/search", limiters.authenticatedCatalogue, (req: Request & { publicCatalogue?: boolean }, _res: unknown, next: () => void) => {
  req.publicCatalogue = true;
  next();
}, controller.getBooks);

router.post("/books/:id/restore", requireCatalogRole, validateBookId, controller.restoreBook);

module.exports = router;
