import type { Pool, PoolConnection, ResultSetHeader, RowDataPacket } from "mysql2/promise";

const db = require("../../db") as Pool;
const { availableToBorrow, hasActiveBookPolicy } = require("./copyEligibility");
type QueryConnection = Pool | PoolConnection;
type HoldingRow = RowDataPacket & Record<string, any>;
interface CopyHolding extends HoldingRow {
  id: number;
  book_id: number;
  barcode: string;
  title: string;
  accession_number: string | null;
}
interface HoldingDetails {
  accessionNumber: string | null;
  price: string | null;
  programId: number | null;
  courseCode: string | null;
  location: string | null;
  dateAcquired: string | null;
  distributor: string | null;
  invoiceReference: string | null;
}
interface HoldingSearchOptions {
  bookId?: number | null;
  query?: string;
  programId?: number | null;
  status?: string;
  completion?: string;
  page?: number;
  limit?: number;
}

const holdingSelect = `
  SELECT bc.id AS copy_id, bc.book_id, bc.barcode, bc.condition, bc.is_active,
         bk.title, bk.author, bk.isbn, bk.deleted_at AS book_deleted_at,
         bt.name AS book_type, (bk.material_type = 'book' AND NOT ${hasActiveBookPolicy("bk")}) AS needs_policy,
         ${availableToBorrow("bc")} AS borrow_eligible,
         h.accession_number, (voided_accession.accession_number IS NOT NULL) AS accession_voided,
         h.price, h.program_id, ap.name AS course, ap.is_active AS program_is_active,
         h.course_code, h.location, h.date_acquired, h.distributor,
         h.invoice_reference,
         CASE WHEN br.id IS NOT NULL THEN 'borrowed'
              WHEN rr.id IS NOT NULL THEN 'reserved'
              ELSE 'available' END AS circulation_status,
         br.due_date, borrower.name AS borrower_name,
         EXISTS(SELECT 1 FROM borrowings ab WHERE ab.copy_id = bc.id AND ab.deleted_at IS NULL AND ab.status IN ('borrowed','overdue')) AS has_active_loan,
         EXISTS(SELECT 1 FROM reservations ar WHERE ar.reserved_copy_id = bc.id AND ar.status = 'ready' AND ar.deleted_at IS NULL AND (ar.expires_at IS NULL OR ar.expires_at > NOW())) AS has_ready_reservation
    FROM book_copies bc
    JOIN books bk ON bk.id = bc.book_id
    LEFT JOIN book_types bt ON bt.id = bk.book_type_id
    LEFT JOIN copy_holdings h ON h.copy_id = bc.id
    LEFT JOIN accession_claim_voids voided_accession ON voided_accession.accession_number = h.accession_number
    LEFT JOIN academic_programs ap ON ap.id = h.program_id
    LEFT JOIN borrowings br ON br.copy_id = bc.id AND br.deleted_at IS NULL AND br.status IN ('borrowed','overdue')
    LEFT JOIN users borrower ON borrower.id = br.user_id
    LEFT JOIN reservations rr ON rr.reserved_copy_id = bc.id AND rr.status = 'ready' AND rr.deleted_at IS NULL AND (rr.expires_at IS NULL OR rr.expires_at > NOW())`;

const getBookHoldings = async (bookId: number): Promise<HoldingRow[]> => {
  const [rows] = await db.query<HoldingRow[]>(
    `${holdingSelect} WHERE bc.book_id = ? AND bc.deleted_at IS NULL AND bk.deleted_at IS NULL ORDER BY bc.id ASC`,
    [bookId],
  );
  return rows;
};

const searchHoldings = async ({ query = "", programId = null, bookId = null, status = "all", completion = "all", page = 1, limit = 25 }: HoldingSearchOptions = {}): Promise<{ rows: HoldingRow[]; total: number; page: number; limit: number; summary: Record<string,number> }> => {
  const safePage = Math.max(1, Number(page) || 1);
  const safeLimit = Math.min(100, Math.max(1, Number(limit) || 25));
  const like = `%${String(query).trim()}%`;
  const where = ["bc.deleted_at IS NULL", "bk.deleted_at IS NULL"];
  const params: any[] = [];
  if (query.trim()) {
    where.push("(bk.title LIKE ? OR bk.author LIKE ? OR bk.isbn LIKE ? OR bc.barcode LIKE ? OR h.accession_number LIKE ? OR h.course_code LIKE ? OR h.location LIKE ?)");
    params.push(like, like, like, like, like, like, like);
  }
  if (bookId) { where.push("bc.book_id = ?"); params.push(bookId); }
  if (programId) { where.push("h.program_id = ?"); params.push(programId); }
  const summaryWhere = `WHERE ${where.join(" AND ")}`;
  const summaryParams = [...params];
  if (completion === "complete") where.push("h.accession_number IS NOT NULL AND NOT EXISTS (SELECT 1 FROM accession_claim_voids completion_void WHERE completion_void.accession_number = h.accession_number)");
  if (completion === "missing") where.push("NULLIF(TRIM(h.accession_number), '') IS NULL AND bc.is_active = 1");
  if (status === "inactive") where.push("bc.is_active = 0");
  else if (status === "voided") where.push("EXISTS (SELECT 1 FROM accession_claim_voids status_void WHERE status_void.accession_number = h.accession_number)");
  else if (status === "borrowed") where.push("br.id IS NOT NULL");
  else if (status === "reserved") where.push("br.id IS NULL AND rr.id IS NOT NULL");
  else if (status === "available") where.push(availableToBorrow("bc"));
  const whereSql = `WHERE ${where.join(" AND ")}`;
  const fromSql = `FROM book_copies bc JOIN books bk ON bk.id = bc.book_id
    LEFT JOIN copy_holdings h ON h.copy_id = bc.id
    LEFT JOIN borrowings br ON br.copy_id = bc.id AND br.deleted_at IS NULL AND br.status IN ('borrowed','overdue')
    LEFT JOIN reservations rr ON rr.reserved_copy_id = bc.id AND rr.status = 'ready' AND rr.deleted_at IS NULL AND (rr.expires_at IS NULL OR rr.expires_at > NOW())`;
  const [[counts]] = await db.query<HoldingRow[]>(`SELECT COUNT(DISTINCT bc.id) AS all_count,
    COUNT(DISTINCT CASE WHEN NULLIF(TRIM(h.accession_number), '') IS NULL AND bc.is_active = 1 THEN bc.id END) AS needs_count,
    COUNT(DISTINCT CASE WHEN ${availableToBorrow("bc")} THEN bc.id END) AS available_count,
    COUNT(DISTINCT CASE WHEN br.id IS NOT NULL THEN bc.id END) AS borrowed_count,
    COUNT(DISTINCT CASE WHEN br.id IS NULL AND rr.id IS NOT NULL THEN bc.id END) AS reserved_count,
    COUNT(DISTINCT CASE WHEN EXISTS(SELECT 1 FROM accession_claim_voids sv WHERE sv.accession_number = h.accession_number) THEN bc.id END) AS voided_count
    ${fromSql} ${summaryWhere}`,summaryParams);
  const [[{ total }]] = await db.query<Array<HoldingRow & { total: number | string }>>(`SELECT COUNT(DISTINCT bc.id) AS total ${fromSql} ${whereSql}`, params);
  const [rows] = await db.query<HoldingRow[]>(
    `${holdingSelect} ${whereSql} ORDER BY bk.title ASC, bc.id ASC LIMIT ? OFFSET ?`,
    [...params, safeLimit, (safePage - 1) * safeLimit],
  );
  return { rows, total: Number(total), page: safePage, limit: safeLimit, summary: Object.fromEntries(["all","needs","available","borrowed","reserved","voided"].map(key=>[key,Number(counts?.[`${key}_count`]??0)])) };
};

const getCopyForUpdate = async (copyId: number, conn: QueryConnection): Promise<CopyHolding | null> => {
  const [[row]] = await conn.query<CopyHolding[]>(
    `SELECT bc.id, bc.book_id, bc.barcode, bc.condition, bc.is_active, bc.notes,
       bk.title, bk.deleted_at AS book_deleted_at,
       h.accession_number, EXISTS(SELECT 1 FROM accession_claim_voids voided_accession WHERE voided_accession.accession_number = h.accession_number) AS accession_voided,
       h.price, h.program_id, h.course_code, h.location,
       h.date_acquired, h.distributor, h.invoice_reference,
       EXISTS(SELECT 1 FROM borrowings b WHERE b.copy_id = bc.id AND b.deleted_at IS NULL AND b.status IN ('borrowed','overdue')) AS has_active_loan,
       EXISTS(SELECT 1 FROM reservations r WHERE r.reserved_copy_id = bc.id AND r.status = 'ready' AND r.deleted_at IS NULL AND (r.expires_at IS NULL OR r.expires_at > NOW())) AS has_ready_reservation
     FROM book_copies bc JOIN books bk ON bk.id = bc.book_id LEFT JOIN copy_holdings h ON h.copy_id = bc.id
     WHERE bc.id = ? AND bc.deleted_at IS NULL FOR UPDATE`,
    [copyId],
  );
  return row || null;
};

const findProgram = async (programId: number, conn: QueryConnection): Promise<(HoldingRow & { id: number; is_active: number | boolean }) | null> => {
  const [[row]] = await conn.query<Array<HoldingRow & { id: number; is_active: number | boolean }>>("SELECT id, is_active FROM academic_programs WHERE id = ? FOR UPDATE", [programId]);
  return row || null;
};

const insertAccessionClaim = async (copy: CopyHolding, accessionNumber: string, userId: number | null, conn: QueryConnection): Promise<void> => {
  await conn.query(
    `INSERT INTO accession_claims
       (accession_number, copy_barcode, copy_id, book_id, book_title, claimed_by)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [accessionNumber, copy.barcode, copy.id, copy.book_id, copy.title, userId ?? null],
  );
};

const getCopyBookIdentity = async (copyId: number, conn: QueryConnection): Promise<(HoldingRow & { book_id: number }) | null> => {
  const [[row]] = await conn.query<Array<HoldingRow & { book_id: number }>>("SELECT book_id FROM book_copies WHERE id = ? AND deleted_at IS NULL", [copyId]);
  return row || null;
};

const insertAccessionVoid = async (copy: CopyHolding, reason: string, userId: number | null, conn: QueryConnection): Promise<void> => {
  await conn.query(
    `INSERT INTO accession_claim_voids
       (accession_number, copy_barcode, copy_id, book_id, book_title, reason, voided_by)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [copy.accession_number, copy.barcode, copy.id, copy.book_id, copy.title, reason, userId ?? null],
  );
};

const countPendingReservations = async (bookId: number, conn: QueryConnection): Promise<number> => {
  const [[row]] = await conn.query<Array<HoldingRow & { total: number | string }>>(
    "SELECT COUNT(*) AS total FROM reservations WHERE book_id = ? AND status = 'pending' AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at > NOW())",
    [bookId],
  );
  return Number(row.total);
};

const countEligibleCopies = async (bookId: number, excludedCopyId: number, conn: QueryConnection): Promise<number> => {
  const [[row]] = await conn.query<Array<HoldingRow & { total: number | string }>>(
    `SELECT COUNT(*) AS total FROM book_copies bc
       JOIN books bk ON bk.id = bc.book_id
      WHERE bc.book_id = ? AND ${availableToBorrow("bc")}
        AND (? IS NULL OR bc.id <> ?)`,
    [bookId, excludedCopyId, excludedCopyId],
  );
  return Number(row.total);
};

const insertHolding = async (copyId: number, value: HoldingDetails, userId: number | null, conn: QueryConnection): Promise<void> => {
  await conn.query(
    `INSERT INTO copy_holdings
       (copy_id, accession_number, price, program_id, course_code, location, date_acquired, distributor, invoice_reference, created_by, updated_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [copyId, value.accessionNumber, value.price, value.programId, value.courseCode, value.location, value.dateAcquired,
      value.distributor, value.invoiceReference, userId ?? null, userId ?? null],
  );
};

const updateHoldingDetails = async (copyId: number, value: HoldingDetails, userId: number | null, conn: QueryConnection): Promise<number> => {
  const [result] = await conn.query<ResultSetHeader>(
    `UPDATE copy_holdings SET price = ?, program_id = ?, course_code = ?, location = ?,
       date_acquired = ?, distributor = ?, invoice_reference = ?, updated_by = ?
     WHERE copy_id = ?`,
    [value.price, value.programId, value.courseCode, value.location, value.dateAcquired,
      value.distributor, value.invoiceReference, userId ?? null, copyId],
  );
  return Number(result.affectedRows);
};

const getHoldingForCopy = async (copyId: number, conn: QueryConnection): Promise<HoldingRow | null> => {
  const [[row]] = await conn.query<HoldingRow[]>(
    `SELECT bc.id, bc.book_id, bc.barcode, bk.title, h.accession_number,
       EXISTS(SELECT 1 FROM accession_claim_voids voided_accession WHERE voided_accession.accession_number = h.accession_number) AS accession_voided, h.price, h.program_id,
       h.course_code, h.location, h.date_acquired, h.distributor, h.invoice_reference
     FROM book_copies bc JOIN books bk ON bk.id = bc.book_id
     LEFT JOIN copy_holdings h ON h.copy_id = bc.id WHERE bc.id = ?`,
    [copyId],
  );
  return row || null;
};

export = {
  getBookHoldings, searchHoldings, getCopyForUpdate, getCopyBookIdentity, findProgram,
  insertAccessionClaim, insertAccessionVoid, countPendingReservations, countEligibleCopies,
  insertHolding, updateHoldingDetails, getHoldingForCopy,
};
