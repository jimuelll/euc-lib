type HttpError = Error & { status: number };
type LoanDurationUnit = "day" | "hour";
type FineInterval = "hour" | "day";

interface BookTypeInput {
  name?: string | null;
  defaultBorrowDays?: number | string;
  durationMinutes?: number | string;
  durationUnit?: LoanDurationUnit;
  finePerHour?: number | string;
  fineInterval?: FineInterval;
  initialFine?: number | string;
}

function httpError(message: string, status: number): HttpError {
  return Object.assign(new Error(message), { status });
}

function normalizeIsbn(value: unknown): string {
  return String(value || "").replace(/[^0-9Xx]/g, "").toUpperCase();
}

function validateIsbn(value: unknown): string {
  const isbn = normalizeIsbn(value);
  const isbn10 = /^\d{9}[\dX]$/.test(isbn) && [...isbn].reduce((sum, digit, index) => sum + (digit === "X" ? 10 : Number(digit)) * (10 - index), 0) % 11 === 0;
  const isbn13 = /^\d{13}$/.test(isbn) && [...isbn].reduce((sum, digit, index) => sum + Number(digit) * (index % 2 ? 3 : 1), 0) % 10 === 0;
  if (!isbn10 && !isbn13) {
    throw httpError("Enter a valid ISBN-10 or ISBN-13", 400);
  }
  return isbn;
}

function validateBookTypeInput({ name, defaultBorrowDays, durationMinutes, durationUnit = "day", finePerHour, fineInterval = "hour", initialFine = 0 }: BookTypeInput) {
  const minutes = durationMinutes === undefined || durationMinutes === "" ? Number(defaultBorrowDays) * 1440 : Number(durationMinutes);
  const days = durationUnit === "day" ? minutes / 1440 : null;
  const fine = Number(finePerHour);
  const initial = Number(initialFine);
  if (!name?.trim() || !Number.isInteger(minutes) || minutes < 1 || minutes > 525600 || !["day", "hour"].includes(durationUnit) || (durationUnit === "day" && minutes % 1440 !== 0) || !Number.isFinite(fine) || fine < 0 || !["hour", "day"].includes(fineInterval) || !Number.isFinite(initial) || initial < 0) {
    throw httpError("Enter a valid policy with non-negative fines", 400);
  }
  if(name.trim().length>100) throw Object.assign(httpError('Use 100 characters or fewer.',400),{field:'name'});
  for(const [field,value] of [['fine_per_hour',fine],['initial_fine',initial]] as const){
    if(value>99999999.99 || Math.abs(value*100-Math.round(value*100))>0.000001) throw Object.assign(httpError('Enter an amount up to ₱99,999,999.99 with no more than two decimals.',400),{field});
  }
  return { name: name.trim(), days, minutes, durationUnit, fine, fineInterval, initial };
}

export = { httpError, normalizeIsbn, validateBookTypeInput, validateIsbn };
