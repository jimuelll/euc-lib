import express = require("express");
import type { Request, Response } from "express";

const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

const {
  authRoutes,
  adminRoutes,
  catalogRoutes,
  publicCatalogRoutes,
  recommendationPublicRoutes,
  recommendationRoutes,
  borrowingRoutes,
  reservationRoutes,
  adminReservationRoutes,
  circulationRoutes,
  bulletinRoutes,
  eventRoutes,
  aboutRoutes,
  attendanceRoutes,
  subscriptionsRoutes,
  analyticsRoutes,
  analyticsAdminRoutes,
  myLibraryRoutes,
  notificationsRoutes,
  librarySettingsRoutes,
  backupRoutes,
  clearanceRoutes,
  siteContentRoutes,
  userGuideRoutes,
  queryRoutes,
  publishingRoutes,
} = require("./modules");
const maintenanceMode = require("./middlewares/maintenanceMode");
const auditLogger = require("./middlewares/auditLogger");
const { limiters, rateLimitExposedHeaders } = require("./middlewares/rateLimiter");

const { authMiddleware, optionalAuthMiddleware } = require("./modules/auth/auth.middleware");
const { operationsRequestAllowed } = require("./modules/auth/operations-access");
const { forcePasswordChange } = require("./modules/auth/forcePasswordChange.middleware");

const app = express();
app.use(require("./modules/analytics/audit.context").auditRequestContext);
const backupBodyLimit = Number(process.env.BACKUP_MAX_BYTES || 50 * 1024 * 1024);
app.set("trust proxy", 1);
app.use(cors({
  origin: (
    origin: string | undefined,
    callback: (error: Error | null, allow?: boolean) => void,
  ) => {
    const allowed = [
      "http://localhost:8080",
      "http://localhost:5173",
      "https://euc-lib.vercel.app",
      "https://euc-lib-git-master-jimuellls-projects.vercel.app",
    ];
    if (!origin || allowed.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true,
  exposedHeaders: rateLimitExposedHeaders,
}));
app.use(helmet());
app.use(morgan("dev", {
  // Keep successful traffic out of production logs; 5xx requests remain visible.
  skip: (_req: Request, res: Response) => process.env.NODE_ENV === "production" && res.statusCode < 500,
}));
// Bound all API traffic before parsing request bodies. CORS handles preflight
// requests above this middleware, so OPTIONS requests do not consume quota.
app.use("/api", limiters.api);
app.use(cookieParser());
app.use(express.json({ limit: `${backupBodyLimit}b` }));
app.use(express.urlencoded({ extended: true }));

// A restore replaces application data atomically.  This must run before every
// route (including public routes) so a public visit, like, or comment cannot
// be written into the state that is being replaced.
app.use(maintenanceMode);
// Check terminal-account permissions before public and individually authenticated routers.
app.use(optionalAuthMiddleware());
app.use((req: Request & { user?: { role: string } }, res: Response, next: express.NextFunction) => {
  if (!operationsRequestAllowed(req.user?.role, req.method, req.originalUrl)) return void res.status(403).json({ message: "Forbidden" });
  next();
});
app.use(auditLogger);

// --- Public Routes ---
app.use("/api/auth", authRoutes);
app.use("/api/bulletin", bulletinRoutes);
app.use("/api/events", eventRoutes);
app.use("/api/about", aboutRoutes);
app.use("/api/site-content", siteContentRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api", publicCatalogRoutes);
app.use("/api", recommendationPublicRoutes);
app.use("/api/admin/users", require("./modules/admin/barcode.routes"));

// --- Global Protection ---
app.use(authMiddleware());
app.use(forcePasswordChange);
// --- Protected Routes ---
app.use("/api/admin", require("./modules/auth/account-email.routes").adminRouter);
app.use("/api/admin", adminRoutes);
app.use("/api/admin", analyticsAdminRoutes);
app.use("/api/admin", queryRoutes);
app.use("/api/admin", catalogRoutes);
app.use("/api/admin", circulationRoutes);
app.use("/api/borrowing", borrowingRoutes);
app.use("/api/reservations", reservationRoutes);
app.use("/api/admin", adminReservationRoutes);
app.use("/api/admin/about", aboutRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api", subscriptionsRoutes);
app.use("/api", myLibraryRoutes);
app.use("/api", recommendationRoutes);
app.use("/api", notificationsRoutes);
app.use("/api/admin", librarySettingsRoutes);
app.use("/api/admin", backupRoutes);
app.use("/api/admin", clearanceRoutes);
app.use("/api/admin/publishing", publishingRoutes);
app.use("/api", userGuideRoutes);

export = app;
