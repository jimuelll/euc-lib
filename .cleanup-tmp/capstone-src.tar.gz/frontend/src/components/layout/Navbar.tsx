import { HeaderBrand, HeaderAvatar } from "./HeaderIdentity";
import KioskHeader from "./KioskHeader";
import { operationsHome } from "@/utils/operationsAccess";
import { LibraryDesignProvider } from "@/components/ui/library-design";
import { useState, useEffect, useRef } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Menu, X, Bell, QrCode, LogOut, UserCog, LayoutDashboard, ChevronDown,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import ThemeToggle from "@/components/layout/ThemeToggle";
import { useAuth } from "@/context/AuthContext";
import { useNotifications } from "@/context/NotificationsContext";
import type { NotificationItem } from "@/features/notifications/notifications.service";
import { formatNotificationTime } from "@/features/notifications/notification-time";
import { getNavigationPermissions, getUserInitials, isNavigationLinkActive, type NavigationLink } from "./navbar.utils";

const navLinks: NavigationLink[] = [
  { label: "Home",      to: "/",          matchPrefix: false },
  { label: "About",     to: "/about",     matchPrefix: true  },
  { label: "Services",  to: "/services",  matchPrefix: true  },
  { label: "Catalogue", to: "/catalogue", matchPrefix: true  },
  { label: "Bulletin",  to: "/bulletin",  matchPrefix: true  },
];

const myLibraryLink: NavigationLink = { label: "My Library", to: "/my-library", matchPrefix: true };

const AuthSkeleton = () => (
  <div className="h-8 w-8 bg-primary/20 animate-pulse" />
);

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuRef = useRef<HTMLElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const location  = useLocation();
  const navigate  = useNavigate();
  const { user, logout, loading } = useAuth();
  const { notifications, unreadCount, openNotification, markAllAsRead } = useNotifications();

  const assignedPage = operationsHome(user?.role);
  const role       = user?.role ?? "guest";
  const isLoggedIn = !!user && !loading;

  const { showAdminPanel, showMyLibrary, showScannerTools } = getNavigationPermissions(role);

  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  useEffect(() => {
    if (!mobileOpen) return;

    const menu = menuRef.current;
    if (!menu) return;
    const focusable = () => Array.from(menu.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ));
    focusable()[0]?.focus();

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setMobileOpen(false);
        menuButtonRef.current?.focus();
        return;
      }
      if (event.key !== "Tab") return;

      const controls = focusable();
      if (!controls.length) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [mobileOpen]);

  const isNavActive = (link: NavigationLink) => isNavigationLinkActive(location.pathname, link);

  const closeMobile = () => setMobileOpen(false);

  if (assignedPage) return <KioskHeader station={role === "scanner" ? "scanner" : "opac"}/>;
  return (
    <>
      <header className="sticky top-0 z-50 border-b border-primary-foreground/15 bg-primary">
        {/* Gold rule */}
        <div className="h-[3px] w-full bg-warning" />

        <div className="container flex h-14 items-center justify-between gap-2">

          {/* Logo */}
          <HeaderBrand />

          {/* Vertical separator */}
          <div className="hidden xl:block h-6 w-px bg-primary-foreground/15 mx-2 shrink-0" />

          {/* Desktop nav */}
          <DesktopNav links={navLinks} isNavActive={isNavActive} showMyLibrary={showMyLibrary} />

          <div className="flex-1 hidden xl:block" />

          {/* ── Right controls ── */}
          {/*
            Key fix: `shrink-0` on the container prevents it from being
            squeezed by the logo or nav. The burger is always last and has
            an explicit `h-9 w-9` so it can never be pushed out of view.
          */}
          <div className="flex items-center gap-0.5 shrink-0">
            {showScannerTools && <ScannerTools onNavigate={navigate} />}

            <div className="text-primary-foreground/70 hover:text-primary-foreground transition-colors">
              <ThemeToggle />
            </div>

            {loading ? (
              <AuthSkeleton />
            ) : isLoggedIn ? (
              <>
                {/* Bell — visible on both mobile and desktop */}
                <div className="hidden xl:block">
                  <NotificationsDropdown
                    notifications={notifications}
                    unreadCount={unreadCount}
                    onNavigate={navigate}
                    onOpenNotification={openNotification}
                    onMarkAllAsRead={markAllAsRead}
                  />
                </div>
                <div className="xl:hidden">
                  <NotificationsDropdown
                    notifications={notifications}
                    unreadCount={unreadCount}
                    onNavigate={navigate}
                    onOpenNotification={openNotification}
                    onMarkAllAsRead={markAllAsRead}
                  />
                </div>
                {/* User dropdown — desktop only, never takes mobile space */}
                <div className="hidden xl:block ml-1">
                  <UserDropdown
                    name={user?.name}
                    role={role}
                    initials={getUserInitials(user?.name)}
                    showAdminPanel={showAdminPanel}
                    onNavigate={navigate}
                    onLogout={logout}
                  />
                </div>
              </>
            ) : (
              /* Login button — desktop only */
              <div className="hidden xl:block ml-2">
                <Link to="/login">
                  <button
                    className="px-4 py-1.5 text-xs font-bold tracking-[0.15em] uppercase border border-primary-foreground/40 text-primary-foreground hover:bg-primary-foreground/10 transition-colors"
                    style={{ fontFamily: "var(--font-heading)" }}
                  >
                    Login
                  </button>
                </Link>
              </div>
            )}

            {/* Burger — fixed dimensions, always last, can never be squeezed */}
            <button
              ref={menuButtonRef}
              className="xl:hidden flex items-center justify-center h-11 w-11 shrink-0 text-primary-foreground/70 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-colors"
              onClick={() => setMobileOpen((o) => !o)}
              aria-label="Toggle menu"
              aria-expanded={mobileOpen}
              aria-controls="mobile-navigation"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile overlay */}
      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/50 xl:hidden"
            onClick={closeMobile}
            aria-hidden="true"
          />

          <nav
            ref={menuRef}
            id="mobile-navigation"
            aria-label="Mobile navigation"
            className="fixed left-0 right-0 top-[var(--public-header-height)] z-40 overflow-y-auto border-b border-primary-foreground/10 bg-primary xl:hidden"
            style={{ maxHeight: "calc(100dvh - var(--public-header-height))" }}
          >
            {/* User identity band */}
            {isLoggedIn && (
              <div className="flex items-center gap-3 px-4 py-3 border-b border-primary-foreground/10 bg-primary-foreground/5">
                <div
                  className="h-8 w-8 border border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground text-xs font-bold tracking-widest flex shrink-0 items-center justify-center"
                  style={{ fontFamily: "var(--font-heading)" }}
                >
                  {getUserInitials(user?.name)}
                </div>
                <div>
                  <p
                    className="text-[12px] font-bold tracking-[0.08em] text-primary-foreground"
                    style={{ fontFamily: "var(--font-heading)" }}
                  >
                    {user?.name}
                  </p>
                  <p className="text-xs text-primary-foreground/80 tracking-[0.15em] uppercase">{role}</p>
                </div>
              </div>
            )}

            {/* Nav links */}
            <div className="py-1">
              {navLinks.map((link) => (
                <MobileNavLink
                  key={link.to}
                  to={link.to}
                  active={isNavActive(link)}
                  onClick={closeMobile}
                >
                  {link.label}
                </MobileNavLink>
              ))}
              {showMyLibrary && (
                <MobileNavLink to="/my-library" active={isNavActive(myLibraryLink)} onClick={closeMobile} gold>
                  My Library
                </MobileNavLink>
              )}
            </div>

            {/* Logged-in actions */}
            {isLoggedIn && (
              <>
                <div className="h-px bg-primary-foreground/10 my-1" />
                {showAdminPanel && (
                  <MobileActionButton
                    icon={LayoutDashboard}
                    onClick={() => { navigate("/admin"); closeMobile(); }}
                  >
                    Admin Dashboard
                  </MobileActionButton>
                )}
                <MobileActionButton
                  icon={UserCog}
                  onClick={() => { navigate("/edit-profile"); closeMobile(); }}
                >
                  Edit Profile
                </MobileActionButton>
                <div className="h-px bg-primary-foreground/10 my-1" />
                <MobileActionButton
                  icon={LogOut}
                  onClick={() => { logout(); closeMobile(); }}
                  destructive
                >
                  Logout
                </MobileActionButton>
              </>
            )}

            {!loading && !isLoggedIn && (
              <div className="px-4 pt-2 pb-3">
                <Link to="/login" onClick={closeMobile}>
                  <button
                    className="flex h-11 w-full items-center justify-center text-xs font-bold tracking-[0.15em] uppercase border border-primary-foreground/40 text-primary-foreground hover:bg-primary-foreground/10 transition-colors"
                    style={{ fontFamily: "var(--font-heading)" }}
                  >
                    Login
                  </button>
                </Link>
              </div>
            )}
          </nav>
        </>
      )}
    </>
  );
};

// ── Desktop nav ───────────────────────────────────────────────────────────────

const DesktopNav = ({
  links, isNavActive, showMyLibrary,
}: {
  links: typeof navLinks;
  isNavActive: (link: typeof navLinks[number]) => boolean;
  showMyLibrary: boolean;
}) => (
  <nav className="hidden items-center xl:flex">
    {links.map((link) => {
      const active = isNavActive(link);
      return (
        <Link
          key={link.to}
          to={link.to}
          aria-current={active ? "page" : undefined}
          className={`relative flex h-14 items-center px-4 text-[11px] font-semibold tracking-[0.1em] uppercase transition-colors duration-200 focus-visible:ring-inset after:absolute after:bottom-2 after:left-4 after:right-4 after:h-0.5 after:bg-warning after:transition-opacity ${
            active
              ? "text-primary-foreground after:opacity-100"
              : "text-primary-foreground/60 hover:text-primary-foreground after:opacity-0 hover:after:opacity-30"
          }`}
          style={{ fontFamily: "var(--font-heading)" }}
        >
          {link.label}
        </Link>
      );
    })}
    {showMyLibrary && (
      <Link
        to="/my-library"
        aria-current={isNavActive(myLibraryLink) ? "page" : undefined}
        className={`relative px-4 h-14 flex items-center text-[11px] font-semibold tracking-[0.1em] uppercase transition-colors after:absolute after:bottom-2 after:left-4 after:right-4 after:h-0.5 after:bg-warning after:transition-opacity ${
          isNavActive(myLibraryLink)
            ? "text-primary-foreground after:opacity-100"
            : "text-warning/90 hover:text-warning after:opacity-0 hover:after:opacity-30"
        }`}
        style={{ fontFamily: "var(--font-heading)" }}
      >
        My Library
      </Link>
    )}
  </nav>
);

// ── User dropdown ─────────────────────────────────────────────────────────────

const NotificationsDropdown = ({
  notifications,
  unreadCount,
  onNavigate,
  onOpenNotification,
  onMarkAllAsRead,
}: {
  notifications: NotificationItem[];
  unreadCount: number;
  onNavigate: (path: string) => void;
  onOpenNotification: (notificationId: number) => void;
  onMarkAllAsRead: () => Promise<void>;
}) => (
  <DropdownMenu modal={false}>
    <DropdownMenuTrigger asChild>
      <button aria-label="Open notifications" className="relative flex h-11 w-11 items-center justify-center text-primary-foreground/60 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-colors">
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <span className="absolute right-1 top-1 inline-flex min-h-4 min-w-4 items-center justify-center rounded-full bg-warning px-1 text-xs font-bold text-primary">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="end" sideOffset={12} className="w-[min(420px,calc(100vw-1rem))] rounded-md border-border/60 p-0 shadow-lg">
      <div className="border-b border-border/30 bg-primary px-4 py-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p
              className="text-[12px] font-bold uppercase tracking-[0.1em] text-primary-foreground"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              Notifications
            </p>
            <p className="mt-1 text-xs text-primary-foreground/80" aria-live="polite">
              {unreadCount} unread {unreadCount === 1 ? 'notification' : 'notifications'}
            </p>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={() => { void onMarkAllAsRead(); }}
              className="min-h-11 text-xs font-bold uppercase tracking-[0.14em] text-[#f9d688] hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              Mark all read
            </button>
          )}
        </div>
      </div>

      <div className="max-h-[420px] overflow-y-auto">
        {notifications.length > 0 ? (
          notifications.slice(0, 8).map((notification) => (
            <DropdownMenuItem key={notification.id} asChild><button
              onClick={() => {
                onOpenNotification(notification.id);
              }}
              className={`flex w-full flex-col items-stretch gap-0 rounded-none border-b border-border/50 px-4 py-3.5 text-left transition-colors focus:bg-muted hover:bg-muted ${
                notification.is_read ? "bg-background" : "bg-warning/5"
              }`}
            >
              <div className="flex w-full items-start justify-between gap-4">
                <p className="min-w-0 break-words text-sm font-semibold leading-snug text-foreground">
                  {notification.title}
                </p>
                <time className="shrink-0 whitespace-nowrap text-xs leading-5 text-muted-foreground" dateTime={notification.created_at}>
                  {formatNotificationTime(notification.created_at)}
                </time>
              </div>
              <p className="mt-1.5 line-clamp-2 w-full break-words text-sm leading-relaxed text-muted-foreground">
                {notification.body}
              </p>
              {!notification.is_read && <span className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-warning"><span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true"/>New</span>}
            </button></DropdownMenuItem>
          ))
        ) : (
          <div className="px-4 py-8 text-center text-sm text-muted-foreground">
            No notifications yet.
          </div>
        )}
      </div>

      <DropdownMenuSeparator className="m-0" />
      <DropdownMenuItem
        onClick={() => onNavigate("/my-library")}
        className="rounded-md px-4 py-3 text-xs font-bold uppercase tracking-[0.12em] text-action"
        style={{ fontFamily: "var(--font-heading)" }}
      >
        View all notifications
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
);

const UserDropdown = ({
  name, role, initials, showAdminPanel, onNavigate, onLogout,
}: {
  name?: string;
  role: string;
  initials: string;
  showAdminPanel: boolean;
  onNavigate: (path: string) => void;
  onLogout: () => void;
}) => (
  <DropdownMenu>
    <DropdownMenuTrigger asChild>
      <button className="flex items-center gap-2 px-2 py-1.5 hover:bg-primary-foreground/10 transition-colors">
        <HeaderAvatar initials={initials} />
        <ChevronDown className="h-3 w-3 text-primary-foreground/40" />
      </button>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="end" sideOffset={12} className="rounded-md border-border/60 shadow-lg min-w-[200px]">
      <div className="px-3 py-2.5 bg-primary border-b border-border/30">
        <p
          className="text-[12px] font-bold tracking-[0.1em] uppercase text-primary-foreground"
          style={{ fontFamily: "var(--font-heading)" }}
        >
          {name}
        </p>
        <p className="text-xs text-primary-foreground/80 tracking-[0.15em] uppercase mt-0.5">{role}</p>
      </div>
      <div className="py-1">
        {showAdminPanel && (
          <DropdownMenuItem onClick={() => onNavigate("/admin")} className="rounded-md text-[12px] tracking-wide">
            <LayoutDashboard className="mr-2.5 h-3.5 w-3.5" />
            Admin Dashboard
          </DropdownMenuItem>
        )}
        <DropdownMenuItem onClick={() => onNavigate("/edit-profile")} className="rounded-md text-[12px] tracking-wide">
          <UserCog className="mr-2.5 h-3.5 w-3.5" />
          Edit Profile
        </DropdownMenuItem>
      </div>
      <DropdownMenuSeparator />
      <DropdownMenuItem onClick={onLogout} className="rounded-md text-[12px] tracking-wide text-destructive focus:text-destructive">
        <LogOut className="mr-2.5 h-3.5 w-3.5" />
        Logout
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
);

// ── Scanner tools ─────────────────────────────────────────────────────────────

const ScannerTools = ({ onNavigate }: { onNavigate: (path: string) => void }) => (
  <button
    aria-label="Open QR scanner"
    className="flex h-11 w-11 items-center justify-center text-primary-foreground/60 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-colors"
    onClick={() => onNavigate("/scan-qr")}
  >
    <QrCode className="h-4 w-4" />
  </button>
);

// ── Mobile primitives ─────────────────────────────────────────────────────────

const MobileNavLink = ({
  to, active, gold, onClick, children,
}: {
  to: string;
  active?: boolean;
  gold?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) => (
  <Link
    to={to}
    onClick={onClick}
    aria-current={active ? "page" : undefined}
    className={`flex min-h-11 items-center px-4 text-xs font-bold tracking-[0.14em] uppercase transition-colors border-l-2 ${
      active
        ? "border-warning text-primary-foreground bg-primary-foreground/[0.08]"
        : gold
          ? "border-transparent text-warning/80 hover:text-warning hover:border-warning/50"
          : "border-transparent text-primary-foreground/55 hover:text-primary-foreground/90 hover:bg-primary-foreground/5"
    }`}
    style={{ fontFamily: "var(--font-heading)" }}
  >
    {children}
  </Link>
);

const MobileActionButton = ({
  icon: Icon, onClick, destructive, children,
}: {
  icon: React.ElementType;
  onClick: () => void;
  destructive?: boolean;
  children: React.ReactNode;
}) => (
  <button
    onClick={onClick}
    className={`flex min-h-11 w-full items-center px-4 text-xs font-bold tracking-[0.14em] uppercase transition-colors border-l-2 border-transparent hover:bg-primary-foreground/5 ${
      destructive
        ? "text-destructive-foreground/70 hover:border-destructive"
        : "text-primary-foreground/55 hover:text-primary-foreground/90"
    }`}
    style={{ fontFamily: "var(--font-heading)" }}
  >
    <Icon className="mr-3 h-3.5 w-3.5" />
    {children}
  </button>
);

export default function ProtectedNavbar() {
  return <LibraryDesignProvider enabled={false}><Navbar /></LibraryDesignProvider>;
}
