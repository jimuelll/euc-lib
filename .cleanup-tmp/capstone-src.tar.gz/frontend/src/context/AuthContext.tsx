import { operationsHome } from "@/utils/operationsAccess";
import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import axiosInstance, {
  setAuthFailureHandler,
  setAuthRefreshHandler,
  setInMemoryToken,
  refreshAccessToken,
} from "@/utils/AxiosInstance";
import { toast } from "@/components/ui/sonner";
import { useLocation, useNavigate } from "react-router-dom";
import { authDestination } from "@/utils/authDestination";

export interface User {
  id: number;
  role: string;
  name: string;
  must_change_password: boolean;
  email_verified?: boolean;
  term_status?: "current" | "expired" | "not_applicable";
  academic_term_name?: string | null;
}

interface AuthContextProps {
  user: User | null;
  isLoggedIn: boolean;
  loading: boolean;
  mustChangePassword: boolean;
  login: (employeeId: string, password: string, rememberMe?: boolean, returnTo?: string) => Promise<void>;
  logout: () => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  getToken: () => string | null;
}

export const AuthContext = createContext<AuthContextProps | undefined>(undefined);

const decodeAccessToken = (token: string): User | null => {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (
      typeof payload?.id !== "number" ||
      typeof payload?.role !== "string" ||
      typeof payload?.name !== "string"
    ) {
      return null;
    }

    return {
      id: payload.id,
      role: payload.role,
      name: payload.name,
      must_change_password: Boolean(payload.must_change_password),
      email_verified: Boolean(payload.email_verified),
      term_status: payload.term_status,
      academic_term_name: payload.academic_term_name ?? null,
    };
  } catch {
    return null;
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const authenticatedUserId = useRef<number | null>(null);

  const applyAccessToken = useCallback((token: string | null) => {
    const nextUser = token ? decodeAccessToken(token) : null;
    if (authenticatedUserId.current !== (nextUser?.id ?? null)) {
      queryClient.clear();
      authenticatedUserId.current = nextUser?.id ?? null;
    }

    setAccessToken(token);
    setInMemoryToken(token);
    setUser(nextUser);
  }, [queryClient]);

  const clearSession = useCallback(() => {
    applyAccessToken(null);
  }, [applyAccessToken]);

  const refreshSession = useCallback(async () => {
    const token = await refreshAccessToken();
    applyAccessToken(token);
    return token;
  }, [applyAccessToken]);

  useEffect(() => {
    setAuthRefreshHandler((token) => {
      applyAccessToken(token);
    });

    setAuthFailureHandler(() => {
      clearSession();
    });

    return () => {
      setAuthRefreshHandler(null);
      setAuthFailureHandler(null);
    };
  }, [applyAccessToken, clearSession]);

  useEffect(() => {
    let cancelled = false;

    const bootstrapAuth = async () => {
      setLoading(true);
      try {
        await refreshSession();
      } catch (refreshError: unknown) {
        if (!cancelled) {
          // A throttled refresh is temporary; keep any active in-memory session.
          // Invalid/expired sessions continue to clear as before.
          const response = (refreshError as { response?: { status?: number; data?: { message?: string } } } | null)?.response;
          if (response?.status === 429) toast.error(response.data?.message || "Too many requests. Try again later.");
          else clearSession();
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    bootstrapAuth();

    return () => {
      cancelled = true;
    };
  }, [refreshSession, clearSession]);

  const logout = useCallback(async () => {
    try {
      await axiosInstance.post("/api/auth/logout", {});
    } catch {
      // Ignore server logout failures and clear local session anyway.
    }

    clearSession();
    navigate("/login", { replace: true });
  }, [clearSession, navigate]);

  const login = useCallback(async (employeeId: string, password: string, rememberMe = true, returnTo?: string) => {
    try {
      const res = await axiosInstance.post("/api/auth/login", {
        student_employee_id: employeeId,
        password,
        rememberMe,
      });

      const token = res.data.accessToken ?? res.data.token;
      if (!token) throw new Error("Invalid login response");
      applyAccessToken(token);

      if (res.data.mustChangePassword) {
        toast.warning("Change your password to unlock library features.");
      }

      navigate(operationsHome(decodeAccessToken(token)?.role) || authDestination(returnTo), { replace: true });
    } catch (err: any) {
      throw new Error(err.response?.data?.message || "Login failed");
    }
  }, [applyAccessToken, navigate]);

  const changePassword = useCallback(async (oldPassword: string, newPassword: string) => {
    if (!user) throw new Error("Not logged in");

    try {
      const res = await axiosInstance.post("/api/auth/change-password", {
        oldPassword,
        newPassword,
      });

      const token = res.data.accessToken ?? res.data.token;
      if (!token) throw new Error("Invalid password change response");
      applyAccessToken(token);

      toast.success("Password changed successfully!");
      if (location.pathname === "/change-password") navigate("/", { replace: true });
    } catch (err: any) {
      throw new Error(err.response?.data?.message || "Failed to change password");
    }
  }, [applyAccessToken, navigate, user, location.pathname]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn: !!user,
        loading,
        login,
        logout,
        changePassword,
        mustChangePassword: user?.must_change_password ?? false,
        getToken: () => accessToken,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
