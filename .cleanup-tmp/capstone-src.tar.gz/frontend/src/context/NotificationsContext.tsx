import { isOperationsRole } from "@/utils/operationsAccess";
import {useLocation,useNavigate} from 'react-router-dom';
import NotificationReader from '@/features/notifications/NotificationReader';
import {LibraryDesignProvider} from '@/components/ui/library-design';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useAuth } from "@/context/AuthContext";
import {
  fetchNotifications,
  fetchUnreadCount,
  markAllNotificationsRead,
  markNotificationRead,
  type NotificationItem,
} from "@/features/notifications/notifications.service";

interface NotificationsContextValue {
  notifications: NotificationItem[];
  unreadCount: number;
  loading: boolean;
  error: string | null;
  markAsRead: (notificationId: number) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  refresh: () => Promise<void>;
  openNotification:(id:number)=>void;
}

const NotificationsContext = createContext<
  NotificationsContextValue | undefined
>(undefined);

const getWebSocketUrl = (baseUrl: string, token: string) => {
  const url = new URL(baseUrl);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = "/ws";
  url.searchParams.set("token", token);
  return url.toString();
};

export const NotificationsProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const { user, loading: authLoading, getToken } = useAuth();
  const operations = isOperationsRole(user?.role);
  const location=useLocation(),navigate=useNavigate(),notificationOpener=useRef<HTMLElement|null>(null);
  const selected=Number(new URLSearchParams(location.search).get('notification'));
  const notificationId=Number.isSafeInteger(selected)&&selected>0?selected:null;
  const openNotification=useCallback((id:number)=>{const active=document.activeElement as HTMLElement;const menu=active?.closest('[role="menu"]');const trigger=menu?Array.from(document.querySelectorAll<HTMLElement>('[aria-controls]')).find(element=>element.getAttribute('aria-controls')===menu.id):undefined;notificationOpener.current=trigger || active;const search=new URLSearchParams(location.search);search.set('notification',String(id));navigate({pathname:location.pathname,search:search.toString()},{state:location.state});},[location,navigate]);
  const closeNotification=()=>{const search=new URLSearchParams(location.search);search.delete('notification');navigate({pathname:location.pathname,search:search.toString()},{replace:true,state:location.state});};
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const refreshRef = useRef<() => Promise<void>>(async () => {});

  const refresh = useCallback(async () => {
    setError(null);
    if (!user?.id || operations) {
      setNotifications([]);
      setUnreadCount(0);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const [items, unread] = await Promise.all([
        fetchNotifications(),
        fetchUnreadCount(),
      ]);
      setNotifications(items);
      setUnreadCount(unread);
    } catch {
      setError("Library updates could not be loaded.");
    } finally {
      setLoading(false);
    }
  }, [user?.id, operations]);

  refreshRef.current = refresh;

  useEffect(() => {
    if (authLoading) return;

    void refresh();
  }, [authLoading, refresh]);

  useEffect(() => {
    if (authLoading || !user?.id || operations) return;

    let cancelled = false;

    const clearReconnectTimer = () => {
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
    };

    const connect = () => {
      const token = getToken();
      if (!token || cancelled) return;

      const socket = new WebSocket(
        getWebSocketUrl(import.meta.env.VITE_BASE_URL, token),
      );
      socketRef.current = socket;

      socket.onopen = () => {
        reconnectAttemptsRef.current = 0;
        void refreshRef.current();
      };

      socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);

          if (payload.type === "notification.bootstrap") {
            setUnreadCount(payload.unreadCount ?? 0);
            void refreshRef.current();
            return;
          }

          if (payload.type === "notification.unread_count") {
            setUnreadCount(payload.unreadCount ?? 0);
            return;
          }

          if (payload.type === "notification.created" && payload.notification) {
            setNotifications((current) => {
              const deduped = current.filter(
                (notification) => notification.id !== payload.notification.id,
              );
              return [payload.notification, ...deduped].slice(0, 20);
            });
            setUnreadCount(payload.unreadCount ?? 0);
            return;
          }

          if (payload.type === "notification.audience_changed") {
            void refreshRef.current();
          }
        } catch {
          // Ignore malformed socket payloads.
        }
      };

      socket.onclose = () => {
        if (cancelled) return;

        const attempt = reconnectAttemptsRef.current + 1;
        reconnectAttemptsRef.current = attempt;
        const delay = Math.min(1000 * 2 ** Math.min(attempt - 1, 4), 15000);

        clearReconnectTimer();
        reconnectTimerRef.current = window.setTimeout(() => {
          connect();
        }, delay);
      };

      socket.onerror = () => {
        socket.close();
      };
    };

    connect();

    return () => {
      cancelled = true;
      clearReconnectTimer();
      socketRef.current?.close();
      socketRef.current = null;
    };
  }, [authLoading, user?.id, getToken, operations]);

  useEffect(() => {
    if (!user?.id || operations) return;

    const syncNotifications = () => {
      void refreshRef.current();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        syncNotifications();
      }
    };

    window.addEventListener("focus", syncNotifications);
    window.addEventListener("online", syncNotifications);
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      window.removeEventListener("focus", syncNotifications);
      window.removeEventListener("online", syncNotifications);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [user?.id, operations]);

  const markAsRead = useCallback(async (notificationId: number) => {
    const result=await markNotificationRead(notificationId);
    setNotifications((current) =>
      current.map((notification) =>
        notification.id === notificationId
          ? {
              ...notification,
              is_read: true,
              read_at: new Date().toISOString(),
            }
          : notification,
      ),
    );
    setUnreadCount((count) => typeof result?.unreadCount==='number'?result.unreadCount:Math.max(0, count - 1));
  },[]);

  const markAllAsRead = useCallback(async () => {
    await markAllNotificationsRead();
    setNotifications((current) =>
      current.map((notification) => ({
        ...notification,
        is_read: true,
        read_at: notification.read_at ?? new Date().toISOString(),
      })),
    );
    setUnreadCount(0);
  },[]);

  const value = useMemo(
    () => ({
      notifications,
      unreadCount,
      loading,
      error,
      markAsRead,
      markAllAsRead,
      refresh,openNotification,
    }),
    [notifications, unreadCount, loading, error, refresh,openNotification,markAsRead,markAllAsRead],
  );

  return (
    <NotificationsContext.Provider value={value}>
      {children}
      <LibraryDesignProvider><NotificationReader key={notificationId || "closed"} id={operations ? null : notificationId} userId={user?.id || null} onClose={closeNotification} onMarkRead={markAsRead} onDestination={href=>navigate(href)} onAfterClose={()=>{const target=notificationOpener.current; if(target?.isConnected)target.focus();else {const fallback=Array.from(document.querySelectorAll<HTMLElement>('[aria-label*="notifications" i]')).find(element=>element.offsetParent!==null) || document.querySelector<HTMLElement>('#admin-main,main');if(fallback){if(!fallback.hasAttribute('tabindex')&&fallback.tagName==='MAIN')fallback.tabIndex=-1;fallback.focus();}}}}/></LibraryDesignProvider>
    </NotificationsContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationsContext);
  if (!context)
    throw new Error(
      "useNotifications must be used within NotificationsProvider",
    );
  return context;
};
